"""Tests for the AI sentiment engine and the AI microservice API (CO5)."""
import importlib.util
import sys
from pathlib import Path

AI_DIR = Path(__file__).resolve().parents[1] / "ai_service"
sys.path.insert(0, str(AI_DIR))
import analyzer  # noqa: E402


def test_positive():
    r = analyzer.analyze_text("Excellent teaching and very helpful faculty")
    assert r["sentiment"] == "positive" and r["positive_score"] > r["negative_score"]


def test_negative():
    r = analyzer.analyze_text("Very poor service and bad experience")
    assert r["sentiment"] == "negative" and r["negative_score"] > r["positive_score"]


def test_neutral():
    assert analyzer.analyze_text("The service is average")["sentiment"] == "neutral"


def test_negation_flips_polarity():
    assert analyzer.analyze_text("The lectures were not good")["sentiment"] == "negative"


def test_scores_are_valid():
    r = analyzer.analyze_text("Great food but slow service")
    assert 0 <= r["confidence"] <= 1
    assert abs(r["positive_score"] + r["negative_score"] + r["neutral_score"] - 1) < 0.01


def test_empty_text_rejected():
    try:
        analyzer.analyze_text("   ")
        assert False, "should raise"
    except ValueError:
        pass


def _client():
    from fastapi.testclient import TestClient
    spec = importlib.util.spec_from_file_location("ai_main", AI_DIR / "main.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return TestClient(mod.app)


def test_service_health_and_analyze():
    c = _client()
    assert c.get("/health").json()["status"] == "ok"
    r = c.post("/analyze", json={"text": "Excellent teaching and very helpful faculty"})
    assert r.status_code == 200 and r.json()["sentiment"] == "positive"
    assert c.post("/analyze", json={"text": ""}).status_code == 422
