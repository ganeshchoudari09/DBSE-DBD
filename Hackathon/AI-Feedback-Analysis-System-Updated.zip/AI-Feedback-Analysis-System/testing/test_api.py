"""End-to-end API tests (CO3/CO6). Uses a temp SQLite DB; the AI service call is routed to the real analyzer."""
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
_tmp = tempfile.mkdtemp()
os.environ["DATABASE_URL"] = f"sqlite:///{Path(_tmp, 'test.db').as_posix()}"
os.environ["ADMIN_EMAIL"] = "admin@test.com"
os.environ["ADMIN_PASSWORD"] = "Admin@123"
sys.path[:0] = [str(ROOT / "backend"), str(ROOT / "ai_service")]

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

import analyzer  # noqa: E402
from app import ai_client  # noqa: E402
from app.main import app  # noqa: E402


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        yield c


@pytest.fixture(autouse=True)
def ai_up(monkeypatch):
    monkeypatch.setattr(ai_client, "analyze", lambda text: analyzer.analyze_text(text))


def auth(client, email, password):
    r = client.post("/api/auth/login", json={"email": email, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


def register(client, name, email):
    r = client.post("/api/auth/register", json={"name": name, "email": email, "password": "secret1"})
    assert r.status_code == 201, r.text
    return auth(client, email, "secret1")


def test_register_login_me_and_duplicates(client):
    h = register(client, "Alice", "alice@test.com")
    me = client.get("/api/auth/me", headers=h).json()
    assert me["email"] == "alice@test.com" and me["role"] == "user"
    assert client.post("/api/auth/register", json={"name": "Alice", "email": "alice@test.com", "password": "secret1"}).status_code == 409
    assert client.post("/api/auth/login", json={"email": "alice@test.com", "password": "wrong"}).status_code == 401
    assert client.get("/api/auth/me").status_code == 401
    assert client.post("/api/auth/register", json={"name": "X", "email": "bad", "password": "1"}).status_code == 422


def test_categories_rbac(client):
    admin = auth(client, "admin@test.com", "Admin@123")
    user = auth(client, "alice@test.com", "secret1")
    assert client.post("/api/categories", json={"name": "Hostel"}, headers=user).status_code == 403
    r = client.post("/api/categories", json={"name": "Hostel", "description": "Rooms"}, headers=admin)
    assert r.status_code == 201
    assert client.post("/api/categories", json={"name": "hostel"}, headers=admin).status_code == 409
    cid = r.json()["id"]
    assert client.put(f"/api/categories/{cid}", json={"name": "Hostels"}, headers=admin).json()["name"] == "Hostels"
    assert len(client.get("/api/categories", headers=user).json()) >= 7
    assert client.delete(f"/api/categories/{cid}", headers=admin).status_code == 204


def test_feedback_crud_sentiment_and_isolation(client):
    admin = auth(client, "admin@test.com", "Admin@123")
    alice = auth(client, "alice@test.com", "secret1")
    bob = register(client, "Bob", "bob@test.com")
    cat = client.get("/api/categories", headers=alice).json()[0]["id"]

    body = {"title": "Great faculty", "message": "Excellent teaching and very helpful faculty", "category_id": cat, "rating": 5}
    r = client.post("/api/feedback", json=body, headers=alice)
    assert r.status_code == 201
    fb = r.json()
    assert fb["sentiment"]["sentiment"] == "positive" and fb["analysis_status"] == "completed"

    neg = client.post("/api/feedback", json={**body, "title": "Bad", "message": "Very poor service and bad experience", "rating": 1}, headers=alice).json()
    assert neg["sentiment"]["sentiment"] == "negative"
    neu = client.post("/api/feedback", json={**body, "title": "Avg", "message": "The service is average", "rating": 3}, headers=alice).json()
    assert neu["sentiment"]["sentiment"] == "neutral"

    # validation
    assert client.post("/api/feedback", json={**body, "rating": 9}, headers=alice).status_code == 422
    assert client.post("/api/feedback", json={**body, "category_id": 9999}, headers=alice).status_code == 400

    # isolation: Bob cannot see/modify/delete Alice's feedback; lists are scoped
    assert client.get(f"/api/feedback/{fb['id']}", headers=bob).status_code == 404
    assert client.put(f"/api/feedback/{fb['id']}", json={"rating": 1}, headers=bob).status_code == 404
    assert client.delete(f"/api/feedback/{fb['id']}", headers=bob).status_code == 404
    assert client.get("/api/feedback", headers=bob).json()["total"] == 0
    assert client.get("/api/feedback", headers=alice).json()["total"] == 3
    assert client.get("/api/feedback", headers=admin).json()["total"] == 3

    # filters
    assert client.get("/api/feedback?sentiment=negative", headers=admin).json()["total"] == 1
    assert client.get("/api/feedback?search=faculty", headers=admin).json()["total"] == 1

    # update re-analyzes and sets updated_at
    up = client.put(f"/api/feedback/{fb['id']}", json={"message": "Terrible and boring lectures"}, headers=alice).json()
    assert up["sentiment"]["sentiment"] == "negative"
    assert up["updated_at"] is not None

    # admin can delete anything
    assert client.delete(f"/api/feedback/{neu['id']}", headers=admin).status_code == 204
    assert client.get(f"/api/feedback/{neu['id']}", headers=admin).status_code == 404


def test_ai_service_down_is_handled_gracefully(client, monkeypatch):
    monkeypatch.setattr(ai_client, "analyze", lambda text: None)
    alice = auth(client, "alice@test.com", "secret1")
    cat = client.get("/api/categories", headers=alice).json()[0]["id"]
    r = client.post("/api/feedback", json={"title": "Offline", "message": "Good place overall", "category_id": cat, "rating": 4}, headers=alice)
    assert r.status_code == 201 and r.json()["analysis_status"] == "pending" and r.json()["sentiment"] is None
    fid = r.json()["id"]
    assert client.post(f"/api/feedback/{fid}/analyze", headers=alice).status_code == 503
    monkeypatch.setattr(ai_client, "analyze", lambda text: analyzer.analyze_text(text))
    assert client.post(f"/api/feedback/{fid}/analyze", headers=alice).json()["analysis_status"] == "completed"


def test_analytics_reports_and_export(client):
    admin = auth(client, "admin@test.com", "Admin@123")
    alice = auth(client, "alice@test.com", "secret1")
    ov = client.get("/api/analytics/overview", headers=admin).json()
    assert ov["total_users"] == 3 and ov["total_feedback"] == 3
    assert ov["positive"] + ov["negative"] + ov["neutral"] == ov["analyzed"]
    assert client.get("/api/analytics/overview", headers=alice).status_code == 403
    assert client.get("/api/analytics/me", headers=alice).json()["total_feedback"] == 3
    assert sum(client.get("/api/analytics/sentiment", headers=admin).json().values()) == ov["analyzed"]
    assert len(client.get("/api/analytics/ratings", headers=admin).json()["distribution"]) == 5
    assert sum(c["total"] for c in client.get("/api/analytics/categories", headers=admin).json()) == 3
    tr = client.get("/api/analytics/trends?days=7", headers=admin).json()
    assert len(tr) == 7 and sum(t["total"] for t in tr) == 3
    rep = client.post("/api/reports/generate", json={"report_type": "summary"}, headers=admin)
    assert rep.status_code == 200 and rep.json()["data"]["overview"]["total_feedback"] == 3
    csv = client.get("/api/reports/export", headers=admin)
    assert csv.status_code == 200 and csv.text.startswith("id,user,email") and "updated_at" in csv.text.splitlines()[0]
    assert len(csv.text.strip().splitlines()) == 4
    assert client.get("/api/reports/export", headers=alice).status_code == 403
    assert len(client.get("/api/reports", headers=admin).json()) >= 2


def test_complaints_suggestions_and_admin_users(client):
    admin = auth(client, "admin@test.com", "Admin@123")
    alice = auth(client, "alice@test.com", "secret1")
    cat = client.get("/api/categories", headers=alice).json()[0]["id"]

    # Submit a suggestion feedback
    client.post("/api/feedback", json={
        "title": "Facility suggestion",
        "message": "We should improve the wifi in the laboratory and cafeteria please.",
        "category_id": cat,
        "rating": 3
    }, headers=alice)

    # Submit a complaint feedback
    client.post("/api/feedback", json={
        "title": "Wifi issue",
        "message": "The wifi is broken and very slow everyday.",
        "category_id": cat,
        "rating": 1
    }, headers=alice)

    # Analytics complaints & suggestions
    complaints = client.get("/api/analytics/complaints", headers=admin).json()
    assert isinstance(complaints, list)
    assert any("Network / Wi-Fi" in c["issue"] or "Hardware" in c["issue"] for c in complaints)

    suggestions = client.get("/api/analytics/suggestions", headers=admin).json()
    assert isinstance(suggestions, list)
    assert any("improve" in s["message"].lower() or "wifi" in s["message"].lower() for s in suggestions)

    # Reports for complaints and suggestions
    rep_comp = client.post("/api/reports/generate", json={"report_type": "complaints"}, headers=admin)
    assert rep_comp.status_code == 200 and len(rep_comp.json()["data"]) > 0

    rep_sugg = client.post("/api/reports/generate", json={"report_type": "suggestions"}, headers=admin)
    assert rep_sugg.status_code == 200 and len(rep_sugg.json()["data"]) > 0

    # User management
    assert client.get("/api/users", headers=alice).status_code == 403
    users = client.get("/api/users", headers=admin).json()
    assert len(users) >= 3
    alice_user = next(u for u in users if u["email"] == "alice@test.com")
    assert alice_user["feedback_count"] >= 3

    # Update role
    r_up = client.put(f"/api/users/{alice_user['id']}/role", json={"role": "admin"}, headers=admin)
    assert r_up.status_code == 200 and r_up.json()["role"] == "admin"

    # Reset role
    client.put(f"/api/users/{alice_user['id']}/role", json={"role": "user"}, headers=admin)

    # Delete non-admin user
    bob = next(u for u in users if u["email"] == "bob@test.com")
    del_r = client.delete(f"/api/users/{bob['id']}", headers=admin)
    assert del_r.status_code == 204


def test_health(client):
    h = client.get("/api/health").json()
    assert h["database"] == "ok" and "ai_service" in h
