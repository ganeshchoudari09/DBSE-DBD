# Testing

```bash
pip install -r backend/requirements.txt -r ai_service/requirements.txt -r testing/requirements-test.txt
pytest testing -v
```
- `test_ai_service.py` – sentiment engine + AI microservice endpoints
- `test_api.py` – auth, RBAC, CRUD, sentiment storage, analytics, reports, CSV export, AI-down handling
