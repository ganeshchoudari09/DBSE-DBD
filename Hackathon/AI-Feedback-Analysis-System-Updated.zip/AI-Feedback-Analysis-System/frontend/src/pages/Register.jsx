import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../AuthContext.jsx";
import { errMsg } from "../api.js";
import { ErrorBox } from "../components/ui.jsx";

export default function Register() {
  const { register } = useAuth();
  const nav = useNavigate();
  const [f, setF] = useState({ name: "", email: "", password: "", confirm: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    if (f.password !== f.confirm) return setError("Passwords do not match.");
    setBusy(true);
    setError("");
    try {
      await register(f.name, f.email, f.password);
      nav("/dashboard");
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto max-w-md">
      <form onSubmit={submit} className="card space-y-4">
        <h1 className="text-xl font-semibold">Create your account</h1>
        <div><label className="label">Full name</label><input className="input" required minLength={2} value={f.name} onChange={set("name")} /></div>
        <div><label className="label">Email</label><input className="input" type="email" required value={f.email} onChange={set("email")} /></div>
        <div><label className="label">Password</label><input className="input" type="password" required minLength={6} value={f.password} onChange={set("password")} /></div>
        <div><label className="label">Confirm password</label><input className="input" type="password" required value={f.confirm} onChange={set("confirm")} /></div>
        <ErrorBox>{error}</ErrorBox>
        <button className="btn-primary w-full" disabled={busy}>{busy ? "Creating…" : "Sign up"}</button>
        <p className="text-center text-sm text-slate-500">Already registered? <Link className="text-sky-600 hover:underline" to="/login">Log in</Link></p>
      </form>
    </div>
  );
}
