import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { CheckCircle2 } from "lucide-react";
import api, { errMsg } from "../api.js";
import FeedbackForm from "../components/FeedbackForm.jsx";
import { ErrorBox, PageHeader, ScoreBars, SentimentBadge, Spinner } from "../components/ui.jsx";

export default function SubmitFeedback() {
  const [cats, setCats] = useState(null);
  const [error, setError] = useState("");
  const [result, setResult] = useState(null);
  const [formKey, setFormKey] = useState(0);

  useEffect(() => { api.get("/categories").then((r) => setCats(r.data)).catch((e) => setError(errMsg(e))); }, []);

  const submit = async (values) => {
    setError("");
    try {
      const { data } = await api.post("/feedback", values);
      setResult(data);
    } catch (e) { setError(errMsg(e)); }
  };

  const retry = async () => {
    try { const { data } = await api.post(`/feedback/${result.id}/analyze`); setResult(data); setError(""); }
    catch (e) { setError(errMsg(e)); }
  };

  if (!cats) return error ? <ErrorBox>{error}</ErrorBox> : <Spinner />;

  if (result) {
    const s = result.sentiment;
    return (
      <div className="mx-auto max-w-lg">
        <div className="card space-y-4 text-center">
          <CheckCircle2 className="mx-auto text-green-500" size={40} />
          <h1 className="text-xl font-semibold">Thanks for your feedback</h1>
          {s ? (
            <div className="rounded-xl bg-slate-50 p-4 text-left">
              <div className="mb-3 flex items-center justify-between">
                <span className="text-sm text-slate-600">AI sentiment analysis</span>
                <SentimentBadge sentiment={s.sentiment} />
              </div>
              <p className="mb-3 text-xs text-slate-500">Confidence {(s.confidence * 100).toFixed(0)}%</p>
              <ScoreBars s={s} />
            </div>
          ) : (
            <div className="space-y-2 rounded-xl bg-orange-50 p-4 text-sm text-orange-800">
              <p>Your feedback was saved, but the AI analysis is unavailable right now.</p>
              <button className="btn-secondary" onClick={retry}>Retry analysis</button>
            </div>
          )}
          <ErrorBox>{error}</ErrorBox>
          <div className="flex justify-center gap-3">
            <button className="btn-primary" onClick={() => { setResult(null); setFormKey(formKey + 1); }}>Submit another</button>
            <Link to="/history" className="btn-secondary">My feedback</Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-xl">
      <PageHeader title="Submit feedback" subtitle="Your message is analyzed by AI as soon as you submit it." />
      <div className="card"><FeedbackForm key={formKey} categories={cats} onSubmit={submit} error={error} /></div>
    </div>
  );
}
