import { useEffect, useState } from "react";
import { Download, FileBarChart, Printer } from "lucide-react";
import api, { errMsg } from "../api.js";
import { Empty, ErrorBox, PageHeader, Stars, fmtDate } from "../components/ui.jsx";

const TYPES = [
  ["summary", "Executive Summary"],
  ["sentiment", "Sentiment Analysis"],
  ["category", "Category Breakdown"],
  ["trends", "30-Day Trends"],
  ["complaints", "Common Complaints"],
  ["suggestions", "Actionable Suggestions"],
];

function Table({ rows }) {
  if (!rows?.length) return <Empty>No data available.</Empty>;
  const cols = Object.keys(rows[0]);
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-left text-sm">
        <thead className="bg-slate-50 text-slate-600">
          <tr>
            {cols.map((c) => (
              <th key={c} className="px-3 py-2 font-medium capitalize">
                {c.replace(/_/g, " ")}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {rows.map((r, i) => (
            <tr key={i} className="hover:bg-slate-50">
              {cols.map((c) => (
                <td key={c} className="px-3 py-2 text-slate-700">
                  {typeof r[c] === "object" ? JSON.stringify(r[c]) : String(r[c] ?? "")}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

const KeyValues = ({ obj }) => <Table rows={[obj]} />;

export default function Reports() {
  const [report, setReport] = useState(null);
  const [history, setHistory] = useState([]);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState("");

  const loadHistory = () =>
    api.get("/reports").then((r) => setHistory(r.data)).catch((e) => setError(errMsg(e)));

  useEffect(() => {
    loadHistory();
  }, []);

  const generate = async (type) => {
    setBusy(type);
    setError("");
    try {
      const { data } = await api.post("/reports/generate", { report_type: type });
      setReport(data);
      loadHistory();
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setBusy("");
    }
  };

  const exportCsv = async () => {
    setError("");
    try {
      const { data } = await api.get("/reports/export", { responseType: "blob" });
      const url = URL.createObjectURL(data);
      const a = document.createElement("a");
      a.href = url;
      a.download = `feedback_export_${new Date().toISOString().slice(0, 10)}.csv`;
      a.click();
      URL.revokeObjectURL(url);
      loadHistory();
    } catch (e) {
      setError(errMsg(e));
    }
  };

  const printReport = () => {
    window.print();
  };

  const renderReportContent = () => {
    if (!report) return null;
    const t = report.report_type;
    const d = report.data;

    if (t === "summary") {
      return (
        <div className="space-y-4">
          <KeyValues obj={d.overview} />
          <h3 className="text-sm font-semibold text-slate-700">Rating distribution</h3>
          <Table rows={d.ratings} />
        </div>
      );
    }
    if (t === "sentiment") {
      return <KeyValues obj={d} />;
    }
    if (t === "complaints") {
      return (
        <div className="space-y-3">
          <p className="text-xs text-slate-500">Summary of recurrent issues identified in negative submissions:</p>
          <Table rows={d} />
        </div>
      );
    }
    if (t === "suggestions") {
      return (
        <div className="space-y-3">
          <p className="text-xs text-slate-500">Constructive feedback messages containing recommendation triggers:</p>
          <Table rows={d} />
        </div>
      );
    }
    return <Table rows={Array.isArray(d) ? d : [d]} />;
  };

  return (
    <div>
      <div className="print:hidden">
        <PageHeader
          title="Reports & analytics"
          subtitle="Generate reports from live data, print presentation-ready summaries and export CSV"
          action={
            <div className="flex gap-2">
              {report && (
                <button className="btn-secondary" onClick={printReport}>
                  <Printer size={16} /> Print Report
                </button>
              )}
              <button className="btn-primary" onClick={exportCsv}>
                <Download size={16} /> Export CSV
              </button>
            </div>
          }
        />
        <ErrorBox>{error}</ErrorBox>
        <div className="card mt-2">
          <h2 className="mb-3 font-semibold text-slate-800">Generate a report</h2>
          <div className="flex flex-wrap gap-2">
            {TYPES.map(([k, label]) => (
              <button
                key={k}
                className={`btn-secondary ${report?.report_type === k ? "border-sky-400 bg-sky-50 text-sky-700" : ""}`}
                disabled={!!busy}
                onClick={() => generate(k)}
              >
                <FileBarChart size={16} /> {busy === k ? "Generating…" : label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {report && (
        <div className="card mt-4 print:border-none print:shadow-none print:p-0">
          <div className="mb-4 flex flex-wrap items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h2 className="text-xl font-bold capitalize text-slate-800">
                {report.report_type.replace("_", " ")} Report
              </h2>
              <p className="text-xs text-slate-500">
                Generated: {fmtDate(report.generated_at)} · FeedbackIQ Analysis System
              </p>
            </div>
            <div className="hidden print:block text-xs text-slate-400">
              Confidential · Hackathon Demo
            </div>
          </div>
          {renderReportContent()}
        </div>
      )}

      <div className="card mt-4 print:hidden">
        <h2 className="mb-3 font-semibold text-slate-800">Report history</h2>
        {history.length === 0 ? (
          <Empty>No reports generated yet.</Empty>
        ) : (
          <ul className="divide-y divide-slate-100 text-sm">
            {history.slice(0, 10).map((h) => (
              <li key={h.id} className="flex justify-between py-2 text-slate-600">
                <span className="capitalize font-medium">{h.report_type.replace("_", " ")}</span>
                <span className="text-slate-400 text-xs">{fmtDate(h.created_at)}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
