import FeedbackBrowser from "../components/FeedbackBrowser.jsx";
import { PageHeader } from "../components/ui.jsx";

export default function FeedbackManagement() {
  return (
    <div>
      <PageHeader title="Feedback management" subtitle="Search, filter, edit and delete feedback from all users" />
      <FeedbackBrowser admin />
    </div>
  );
}
