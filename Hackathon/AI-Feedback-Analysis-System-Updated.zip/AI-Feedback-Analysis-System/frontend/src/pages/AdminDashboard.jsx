import { useEffect, useState } from "react";
import { AlertTriangle, Frown, Lightbulb, Meh, MessageSquare, Smile, Star, Users } from "lucide-react";
import { Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import api, { errMsg } from "../api.js";
import { Empty, ErrorBox, PageHeader, SENTIMENT, SentimentBadge, Spinner, StatCard, Stars, fmtDate } from "../components/ui.jsx";

export default function AdminDashboard() {
  const [d, setD] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    Promise.all([
      api.get("/analytics/overview"),
      api.get("/analytics/sentiment"),
      api.get("/analytics/trends", { params: { days: 30 } }),
      api.get("/analytics/categories"),
      api.get("/feedback", { params: { limit: 8 } }),
      api.get("/analytics/complaints"),
      api.get("/analytics/suggestions"),
    ]).then(([o, s, t, c, r, comp, sugg]) => setD({
      o: o.data,
      s: s.data,
      t: t.data,
      c: c.data,
      r: r.data.items,
      complaints: comp.data,
      suggestions: sugg.data,
    })).catch((e) => setError(errMsg(e)));
  }, []);

  if (error) return <ErrorBox>{error}</ErrorBox>;
  if (!d) return <Spinner />;

  const pie = Object.entries(d.s).map(([k, v]) => ({ name: SENTIMENT[k].label, value: v, color: SENTIMENT[k].color }));
  const hasSentiment = pie.some((p) => p.value > 0);
  const trend = d.t.map((x) => ({ ...x, label: x.date.slice(5) }));

  return (
    <div>
      <PageHeader title="Admin dashboard" subtitle="Live overview of all feedback" />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <StatCard label="Total users" value={d.o.total_users} icon={Users} />
        <StatCard label="Total feedback" value={d.o.total_feedback} icon={MessageSquare} />
        <StatCard label="Average rating" value={d.o.average_rating.toFixed(1)} icon={Star} tone="amber" />
        <StatCard label="Positive" value={d.o.positive} icon={Smile} tone="green" />
        <StatCard label="Negative" value={d.o.negative} icon={Frown} tone="red" />
        <StatCard label="Neutral" value={d.o.neutral} icon={Meh} tone="orange" />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-5">
        <div className="card lg:col-span-2">
          <h2 className="mb-2 font-semibold">Sentiment distribution</h2>
          {!hasSentiment ? <Empty>No analyzed feedback yet.</Empty> : (
            <ResponsiveContainer width="100%" height={260}>
              <PieChart>
                <Pie data={pie} dataKey="value" nameKey="name" innerRadius={55} outerRadius={90} paddingAngle={2}>
                  {pie.map((p) => <Cell key={p.name} fill={p.color} />)}
                </Pie>
                <Tooltip /><Legend />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>
        <div className="card lg:col-span-3">
          <h2 className="mb-2 font-semibold">Feedback trends (last 30 days)</h2>
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={trend}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="label" tick={{ fontSize: 11 }} interval={4} />
              <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
              <Tooltip /><Legend />
              <Line type="monotone" dataKey="total" name="Total" stroke="#0ea5e9" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="positive" name="Positive" stroke={SENTIMENT.positive.color} dot={false} />
              <Line type="monotone" dataKey="negative" name="Negative" stroke={SENTIMENT.negative.color} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="card mt-4">
        <h2 className="mb-2 font-semibold">Feedback by category</h2>
        <ResponsiveContainer width="100%" height={280}>
          <BarChart data={d.c}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
            <XAxis dataKey="category" tick={{ fontSize: 11 }} />
            <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
            <Tooltip /><Legend />
            <Bar dataKey="positive" name="Positive" stackId="a" fill={SENTIMENT.positive.color} />
            <Bar dataKey="neutral" name="Neutral" stackId="a" fill={SENTIMENT.neutral.color} />
            <Bar dataKey="negative" name="Negative" stackId="a" fill={SENTIMENT.negative.color} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <div className="card">
          <div className="mb-3 flex items-center gap-2">
            <div className="rounded-lg bg-red-100 p-1.5 text-red-600"><AlertTriangle size={18} /></div>
            <div>
              <h2 className="font-semibold text-slate-800">Common Complaints</h2>
              <p className="text-xs text-slate-500">Frequent issues extracted from negative feedback</p>
            </div>
          </div>
          {!d.complaints || d.complaints.length === 0 ? (
            <Empty>No recurrent complaints identified.</Empty>
          ) : (
            <div className="space-y-2.5">
              {d.complaints.map((c, i) => (
                <div key={i} className="flex items-start justify-between rounded-xl bg-slate-50 p-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-slate-800 text-sm">{c.issue}</span>
                      <span className="rounded-full bg-slate-200 px-2 py-0.5 text-[11px] text-slate-600">{c.category}</span>
                    </div>
                    {c.sample_feedback && (
                      <p className="mt-1 text-xs text-slate-500 italic">"{c.sample_feedback}"</p>
                    )}
                  </div>
                  <span className="rounded-full bg-red-100 px-2.5 py-0.5 text-xs font-semibold text-red-700">
                    {c.count} issue{c.count === 1 ? "" : "s"}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="card">
          <div className="mb-3 flex items-center gap-2">
            <div className="rounded-lg bg-sky-100 p-1.5 text-sky-600"><Lightbulb size={18} /></div>
            <div>
              <h2 className="font-semibold text-slate-800">Actionable Suggestions</h2>
              <p className="text-xs text-slate-500">Constructive improvement ideas submitted by users</p>
            </div>
          </div>
          {!d.suggestions || d.suggestions.length === 0 ? (
            <Empty>No specific suggestions found yet.</Empty>
          ) : (
            <div className="space-y-2.5 max-h-[310px] overflow-y-auto pr-1">
              {d.suggestions.map((s) => (
                <div key={s.id} className="rounded-xl bg-slate-50 p-3">
                  <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                    <span className="font-medium text-slate-700">{s.title}</span>
                    <span className="rounded bg-sky-50 px-1.5 py-0.5 text-[10px] text-sky-700 font-medium capitalize">
                      keyword: {s.trigger_keyword}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 line-clamp-2">{s.message}</p>
                  <div className="mt-1 flex items-center gap-2 text-[11px] text-slate-400">
                    <span>by {s.user_name}</span>
                    <span>·</span>
                    <span>{s.category}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="card mt-4 overflow-x-auto">
        <h2 className="mb-3 font-semibold">Recent feedback</h2>
        {d.r.length === 0 ? <Empty>No feedback yet.</Empty> : (
          <table className="w-full text-left text-sm">
            <thead className="text-slate-500"><tr><th className="py-2 font-medium">Title</th><th className="font-medium">User</th><th className="font-medium">Category</th><th className="font-medium">Rating</th><th className="font-medium">Sentiment</th><th className="font-medium">Date</th></tr></thead>
            <tbody className="divide-y divide-slate-100">
              {d.r.map((i) => (
                <tr key={i.id}><td className="py-2 font-medium">{i.title}</td><td>{i.user_name}</td><td>{i.category_name}</td><td><Stars value={i.rating} size={14} /></td><td><SentimentBadge sentiment={i.sentiment?.sentiment} /></td><td className="text-slate-500">{fmtDate(i.created_at)}</td></tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
