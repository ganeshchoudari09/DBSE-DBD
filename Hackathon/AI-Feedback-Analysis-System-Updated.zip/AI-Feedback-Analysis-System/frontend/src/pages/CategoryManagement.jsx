import { useEffect, useState } from "react";
import { Check, Pencil, Plus, Trash2, X } from "lucide-react";
import api, { errMsg } from "../api.js";
import { Empty, ErrorBox, PageHeader, Spinner } from "../components/ui.jsx";

export default function CategoryManagement() {
  const [cats, setCats] = useState(null);
  const [form, setForm] = useState({ name: "", description: "" });
  const [editId, setEditId] = useState(null);
  const [draft, setDraft] = useState({ name: "", description: "" });
  const [error, setError] = useState("");

  const load = () => api.get("/categories").then((r) => setCats(r.data)).catch((e) => setError(errMsg(e)));
  useEffect(() => { load(); }, []);

  const act = async (fn) => { setError(""); try { await fn(); await load(); } catch (e) { setError(errMsg(e)); } };

  const add = (e) => {
    e.preventDefault();
    act(async () => { await api.post("/categories", form); setForm({ name: "", description: "" }); });
  };
  const save = (id) => act(async () => { await api.put(`/categories/${id}`, draft); setEditId(null); });
  const remove = (c) => confirm(`Delete category "${c.name}"?`) && act(() => api.delete(`/categories/${c.id}`));

  return (
    <div>
      <PageHeader title="Categories" subtitle="Organise feedback into topics" />
      <form onSubmit={add} className="card mb-4 grid gap-3 sm:grid-cols-[1fr_2fr_auto]">
        <input className="input" required minLength={2} placeholder="Category name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        <input className="input" placeholder="Description (optional)" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
        <button className="btn-primary"><Plus size={16} /> Add</button>
      </form>
      <ErrorBox>{error}</ErrorBox>
      <div className="card mt-4 overflow-x-auto p-0">
        {!cats ? <Spinner /> : cats.length === 0 ? <Empty>No categories yet.</Empty> : (
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 text-slate-500"><tr><th className="px-4 py-3 font-medium">Name</th><th className="px-4 py-3 font-medium">Description</th><th className="px-4 py-3 font-medium">Feedback</th><th className="px-4 py-3" /></tr></thead>
            <tbody className="divide-y divide-slate-100">
              {cats.map((c) => (
                <tr key={c.id}>
                  {editId === c.id ? (
                    <>
                      <td className="px-4 py-2"><input className="input" value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} /></td>
                      <td className="px-4 py-2"><input className="input" value={draft.description || ""} onChange={(e) => setDraft({ ...draft, description: e.target.value })} /></td>
                      <td className="px-4 py-2">{c.feedback_count}</td>
                      <td className="px-4 py-2"><div className="flex justify-end gap-1"><button className="btn-primary px-2" onClick={() => save(c.id)}><Check size={14} /></button><button className="btn-secondary px-2" onClick={() => setEditId(null)}><X size={14} /></button></div></td>
                    </>
                  ) : (
                    <>
                      <td className="px-4 py-3 font-medium">{c.name}</td>
                      <td className="px-4 py-3 text-slate-500">{c.description}</td>
                      <td className="px-4 py-3">{c.feedback_count}</td>
                      <td className="px-4 py-3"><div className="flex justify-end gap-1"><button className="btn-secondary px-2" onClick={() => { setEditId(c.id); setDraft({ name: c.name, description: c.description || "" }); }}><Pencil size={14} /></button><button className="btn-danger px-2" onClick={() => remove(c)}><Trash2 size={14} /></button></div></td>
                    </>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
