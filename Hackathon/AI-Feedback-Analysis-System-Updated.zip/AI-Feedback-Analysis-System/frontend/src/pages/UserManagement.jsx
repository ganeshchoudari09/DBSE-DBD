import { useEffect, useState } from "react";
import { Shield, ShieldAlert, Trash2, UserCheck, Users, Search } from "lucide-react";
import api, { errMsg } from "../api.js";
import { useAuth } from "../AuthContext.jsx";
import { Empty, ErrorBox, PageHeader, Spinner, StatCard, fmtDate } from "../components/ui.jsx";

export default function UserManagement() {
  const { user: currentAdmin } = useAuth();
  const [users, setUsers] = useState(null);
  const [search, setSearch] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [busyId, setBusyId] = useState(null);

  const load = () => {
    api.get("/users")
      .then((r) => setUsers(r.data))
      .catch((e) => setError(errMsg(e)));
  };

  useEffect(() => { load(); }, []);

  const changeRole = async (targetUser) => {
    const newRole = targetUser.role === "admin" ? "user" : "admin";
    if (targetUser.id === currentAdmin.id && newRole !== "admin") {
      alert("You cannot demote yourself from admin.");
      return;
    }
    if (!confirm(`Change role of ${targetUser.name} to ${newRole.toUpperCase()}?`)) return;
    setBusyId(targetUser.id);
    setError("");
    setSuccess("");
    try {
      await api.put(`/users/${targetUser.id}/role`, { role: newRole });
      setSuccess(`Updated role of ${targetUser.name} to ${newRole}.`);
      load();
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setBusyId(null);
    }
  };

  const deleteUser = async (targetUser) => {
    if (targetUser.id === currentAdmin.id) {
      alert("You cannot delete your own account.");
      return;
    }
    if (!confirm(`Delete user "${targetUser.name}" (${targetUser.email}) and all their feedback? This cannot be undone.`)) return;
    setBusyId(targetUser.id);
    setError("");
    setSuccess("");
    try {
      await api.delete(`/users/${targetUser.id}`);
      setSuccess(`Deleted user "${targetUser.name}".`);
      load();
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setBusyId(null);
    }
  };

  if (!users) return error ? <ErrorBox>{error}</ErrorBox> : <Spinner />;

  const filtered = users.filter((u) =>
    u.name.toLowerCase().includes(search.toLowerCase()) ||
    u.email.toLowerCase().includes(search.toLowerCase())
  );

  const totalAdmins = users.filter((u) => u.role === "admin").length;
  const regularUsers = users.filter((u) => u.role === "user").length;

  return (
    <div>
      <PageHeader
        title="User management"
        subtitle="View registered members, manage user roles and manage access"
      />

      <div className="mb-6 grid gap-4 sm:grid-cols-3">
        <StatCard label="Total registered users" value={users.length} icon={Users} />
        <StatCard label="Administrators" value={totalAdmins} icon={ShieldAlert} tone="sky" />
        <StatCard label="Feedback contributors" value={regularUsers} icon={UserCheck} tone="green" />
      </div>

      <div className="card mb-4 flex items-center gap-3">
        <Search size={18} className="text-slate-400" />
        <input
          className="w-full text-sm outline-none bg-transparent"
          placeholder="Filter by name or email address..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {error && <div className="mb-4"><ErrorBox>{error}</ErrorBox></div>}
      {success && (
        <div className="mb-4 rounded-xl border border-green-200 bg-green-50 px-4 py-2.5 text-sm text-green-700">
          {success}
        </div>
      )}

      <div className="card overflow-x-auto p-0">
        {filtered.length === 0 ? (
          <Empty>No users match your search criteria.</Empty>
        ) : (
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 text-slate-500">
              <tr>
                <th className="px-4 py-3 font-medium">User</th>
                <th className="px-4 py-3 font-medium">Role</th>
                <th className="px-4 py-3 font-medium">Feedback Count</th>
                <th className="px-4 py-3 font-medium">Joined Date</th>
                <th className="px-4 py-3 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((u) => {
                const isMe = u.id === currentAdmin.id;
                return (
                  <tr key={u.id} className="hover:bg-slate-50">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-sky-100 font-semibold text-sky-700">
                          {u.name.slice(0, 2).toUpperCase()}
                        </div>
                        <div>
                          <p className="font-medium text-slate-800">
                            {u.name} {isMe && <span className="text-xs text-sky-600 font-normal">(You)</span>}
                          </p>
                          <p className="text-xs text-slate-500">{u.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium ${
                          u.role === "admin"
                            ? "bg-sky-100 text-sky-700"
                            : "bg-slate-100 text-slate-600"
                        }`}
                      >
                        <Shield size={12} />
                        {u.role === "admin" ? "Admin" : "User"}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="font-semibold text-slate-700">{u.feedback_count}</span> items
                    </td>
                    <td className="whitespace-nowrap px-4 py-3 text-slate-500">
                      {fmtDate(u.created_at)}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex justify-end gap-1.5">
                        <button
                          className="btn-secondary px-2.5 py-1 text-xs"
                          disabled={busyId === u.id || isMe}
                          onClick={() => changeRole(u)}
                          title={`Toggle ${u.role === "admin" ? "to User" : "to Admin"}`}
                        >
                          Make {u.role === "admin" ? "User" : "Admin"}
                        </button>
                        <button
                          className="btn-danger px-2.5 py-1 text-xs"
                          disabled={busyId === u.id || isMe}
                          onClick={() => deleteUser(u)}
                          title="Delete user"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
