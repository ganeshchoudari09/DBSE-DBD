import { Link } from "react-router-dom";
import FeedbackBrowser from "../components/FeedbackBrowser.jsx";
import { PageHeader } from "../components/ui.jsx";

export default function FeedbackHistory() {
  return (
    <div>
      <PageHeader title="My feedback" subtitle="Review, edit or delete what you've submitted"
        action={<Link to="/submit" className="btn-primary">New feedback</Link>} />
      <FeedbackBrowser />
    </div>
  );
}
