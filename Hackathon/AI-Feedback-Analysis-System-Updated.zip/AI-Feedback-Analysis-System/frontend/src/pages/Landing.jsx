import { Link } from "react-router-dom";
import { BarChart3, Brain, MessageSquareText, ShieldCheck } from "lucide-react";
import { useAuth } from "../AuthContext.jsx";

const FEATURES = [
  [Brain, "Instant sentiment analysis", "Every submission is classified as positive, negative or neutral with confidence scores, in seconds."],
  [BarChart3, "Clear analytics", "Admins see sentiment mix, rating trends and category breakdowns drawn from real data."],
  [ShieldCheck, "Private and secure", "Users only see their own feedback. Admins manage everything with role-based access."],
];

export default function Landing() {
  const { user } = useAuth();
  const home = user ? (user.role === "admin" ? "/admin" : "/dashboard") : "/register";
  return (
    <div>
      <section className="rounded-3xl bg-sky-50 px-6 py-16 text-center sm:py-24">
        <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-white text-sky-500 shadow-sm"><MessageSquareText size={28} /></div>
        <h1 className="mx-auto max-w-2xl text-4xl font-bold tracking-tight sm:text-5xl">Understand what people really think</h1>
        <p className="mx-auto mt-4 max-w-xl text-lg text-slate-600">Collect feedback from students, employees and customers, and let AI tell you how they feel.</p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Link to={home} className="btn-primary px-6 py-3">{user ? "Go to dashboard" : "Get started"}</Link>
          {!user && <Link to="/login" className="btn-secondary px-6 py-3">Log in</Link>}
        </div>
      </section>
      <section className="mt-10 grid gap-4 md:grid-cols-3">
        {FEATURES.map(([Icon, title, text]) => (
          <div key={title} className="card">
            <div className="mb-3 inline-flex rounded-xl bg-sky-100 p-2.5 text-sky-600"><Icon size={20} /></div>
            <h3 className="font-semibold">{title}</h3>
            <p className="mt-1 text-sm text-slate-600">{text}</p>
          </div>
        ))}
      </section>
      <section className="mt-10 rounded-2xl bg-slate-100 p-8">
        <h2 className="mb-4 text-xl font-semibold">How it works</h2>
        <ol className="grid gap-4 text-sm text-slate-600 sm:grid-cols-3">
          <li><b className="text-slate-800">1. Submit.</b> Write a title and message, pick a category and give a star rating.</li>
          <li><b className="text-slate-800">2. Analyze.</b> The AI service scores the text and returns a sentiment right away.</li>
          <li><b className="text-slate-800">3. Act.</b> Admins review trends and export reports to improve what matters.</li>
        </ol>
      </section>
      <footer className="py-8 text-center text-sm text-slate-400">FeedbackIQ – AI-Based Feedback Analysis System</footer>
    </div>
  );
}
