import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Frown, Meh, MessageSquare, Smile, Star } from "lucide-react";
import api, { errMsg } from "../api.js";
import { useAuth } from "../AuthContext.jsx";
import { Empty, ErrorBox, PageHeader, SentimentBadge, Spinner, StatCard, Stars, fmtDate } from "../components/ui.jsx";

export default function UserDashboard() {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [recent, setRecent] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    Promise.all([api.get("/analytics/me"), api.get("/feedback", { params: { limit: 5 } })])
      .then(([s, r]) => { setStats(s.data); setRecent(r.data.items); })
      .catch((e) => setError(errMsg(e)));
  }, []);

  if (error) return <ErrorBox>{error}</ErrorBox>;
  if (!stats) return <Spinner />;

  return (
    <div>
      <PageHeader title={`Welcome, ${user.name.split(" ")[0]}`} subtitle="Your feedback activity at a glance"
        action={<Link to="/submit" className="btn-primary">Submit feedback</Link>} />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <StatCard label="Total feedback" value={stats.total_feedback} icon={MessageSquare} />
        <StatCard label="Average rating" value={stats.average_rating.toFixed(1)} icon={Star} tone="amber" />
        <StatCard label="Positive" value={stats.positive} icon={Smile} tone="green" />
        <StatCard label="Negative" value={stats.negative} icon={Frown} tone="red" />
        <StatCard label="Neutral" value={stats.neutral} icon={Meh} tone="orange" />
      </div>
      <div className="card mt-6">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-semibold">Recent feedback</h2>
          <Link to="/history" className="text-sm text-sky-600 hover:underline">View all</Link>
        </div>
        {recent.length === 0 ? <Empty>You haven't submitted any feedback yet.</Empty> : (
          <ul className="divide-y divide-slate-100">
            {recent.map((i) => (
              <li key={i.id} className="flex flex-wrap items-center justify-between gap-2 py-3">
                <div><p className="font-medium">{i.title}</p><p className="text-sm text-slate-500">{i.category_name} · {fmtDate(i.created_at)}</p></div>
                <div className="flex items-center gap-3"><Stars value={i.rating} size={14} /><SentimentBadge sentiment={i.sentiment?.sentiment} /></div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
