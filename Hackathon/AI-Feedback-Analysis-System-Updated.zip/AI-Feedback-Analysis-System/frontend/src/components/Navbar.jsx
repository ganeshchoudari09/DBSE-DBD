import { useState } from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import { LogOut, Menu, MessageSquareText, X } from "lucide-react";
import { useAuth } from "../AuthContext.jsx";

const USER_LINKS = [["/dashboard", "Dashboard"], ["/submit", "Submit feedback"], ["/history", "My feedback"]];
const ADMIN_LINKS = [["/admin", "Dashboard"], ["/admin/feedback", "Feedback"], ["/admin/categories", "Categories"], ["/admin/reports", "Reports"], ["/admin/users", "Users"]];

export default function Navbar() {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  const [open, setOpen] = useState(false);
  const links = !user ? [] : user.role === "admin" ? ADMIN_LINKS : USER_LINKS;
  const cls = ({ isActive }) =>
    `rounded-lg px-3 py-2 text-sm font-medium ${isActive ? "bg-sky-50 text-sky-700" : "text-slate-600 hover:bg-slate-100"}`;

  return (
    <header className="sticky top-0 z-40 border-b border-slate-200 bg-white/90 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
        <Link to="/" className="flex items-center gap-2 text-lg font-semibold text-sky-600">
          <MessageSquareText size={22} /> FeedbackIQ
        </Link>
        <nav className="hidden items-center gap-1 md:flex">
          {links.map(([to, label]) => <NavLink key={to} to={to} end className={cls}>{label}</NavLink>)}
        </nav>
        <div className="hidden items-center gap-2 md:flex">
          {user ? (
            <>
              <span className="text-sm text-slate-500">{user.name}{user.role === "admin" && " (admin)"}</span>
              <button className="btn-secondary" onClick={() => { logout(); nav("/"); }}><LogOut size={16} /> Log out</button>
            </>
          ) : (
            <>
              <Link to="/login" className="btn-secondary">Log in</Link>
              <Link to="/register" className="btn-primary">Sign up</Link>
            </>
          )}
        </div>
        <button className="md:hidden" onClick={() => setOpen(!open)} aria-label="Menu">{open ? <X /> : <Menu />}</button>
      </div>
      {open && (
        <div className="space-y-1 border-t border-slate-200 bg-white px-4 py-3 md:hidden" onClick={() => setOpen(false)}>
          {links.map(([to, label]) => <NavLink key={to} to={to} end className={cls}>{label}</NavLink>)}
          {user ? (
            <button className="btn-secondary w-full" onClick={() => { logout(); nav("/"); }}>Log out</button>
          ) : (
            <div className="flex gap-2"><Link to="/login" className="btn-secondary flex-1">Log in</Link><Link to="/register" className="btn-primary flex-1">Sign up</Link></div>
          )}
        </div>
      )}
    </header>
  );
}
