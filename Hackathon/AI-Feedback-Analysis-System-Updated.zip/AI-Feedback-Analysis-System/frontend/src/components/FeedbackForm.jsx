import { useState } from "react";
import { Send } from "lucide-react";
import { ErrorBox, StarInput } from "./ui.jsx";

export default function FeedbackForm({ categories, initial, onSubmit, submitLabel = "Submit feedback", error }) {
  const [v, setV] = useState(initial || { title: "", message: "", category_id: "", rating: 0 });
  const [local, setLocal] = useState("");
  const [busy, setBusy] = useState(false);
  const set = (k, val) => setV((p) => ({ ...p, [k]: val }));

  const handle = async (e) => {
    e.preventDefault();
    if (!v.category_id) return setLocal("Choose a category.");
    if (!v.rating) return setLocal("Select a star rating.");
    setLocal("");
    setBusy(true);
    try {
      await onSubmit({ ...v, category_id: Number(v.category_id) });
    } finally {
      setBusy(false);
    }
  };

  return (
    <form onSubmit={handle} className="space-y-4">
      <div>
        <label className="label">Title</label>
        <input className="input" required minLength={3} maxLength={150} value={v.title} onChange={(e) => set("title", e.target.value)} placeholder="Summarise your feedback" />
      </div>
      <div>
        <label className="label">Category</label>
        <select className="input" value={v.category_id} onChange={(e) => set("category_id", e.target.value)}>
          <option value="">Select a category</option>
          {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </div>
      <div>
        <label className="label">Rating</label>
        <StarInput value={v.rating} onChange={(n) => set("rating", n)} />
      </div>
      <div>
        <label className="label">Your feedback</label>
        <textarea className="input min-h-[120px]" required minLength={5} maxLength={5000} value={v.message} onChange={(e) => set("message", e.target.value)} placeholder="Tell us what went well and what could improve" />
      </div>
      <ErrorBox>{local || error}</ErrorBox>
      <button className="btn-primary w-full" disabled={busy}><Send size={16} /> {busy ? "Saving…" : submitLabel}</button>
    </form>
  );
}
