import { useCallback, useEffect, useState } from "react";
import { ChevronLeft, ChevronRight, Pencil, RefreshCw, Search, Trash2 } from "lucide-react";
import api, { errMsg } from "../api.js";
import FeedbackForm from "./FeedbackForm.jsx";
import { Empty, ErrorBox, Modal, ScoreBars, SentimentBadge, Spinner, Stars, fmtDate } from "./ui.jsx";

const LIMIT = 10;

export default function FeedbackBrowser({ admin = false }) {
  const [items, setItems] = useState([]);
  const [total, setTotal] = useState(0);
  const [cats, setCats] = useState([]);
  const [f, setF] = useState({ search: "", sentiment: "", category_id: "" });
  const [page, setPage] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [view, setView] = useState(null);
  const [edit, setEdit] = useState(null);
  const [editErr, setEditErr] = useState("");

  const load = useCallback(() => {
    setLoading(true);
    const params = { skip: page * LIMIT, limit: LIMIT };
    Object.entries(f).forEach(([k, v]) => v && (params[k] = v));
    api.get("/feedback", { params })
      .then((r) => { setItems(r.data.items); setTotal(r.data.total); setError(""); })
      .catch((e) => setError(errMsg(e)))
      .finally(() => setLoading(false));
  }, [f, page]);

  useEffect(() => { const t = setTimeout(load, 250); return () => clearTimeout(t); }, [load]);
  useEffect(() => { api.get("/categories").then((r) => setCats(r.data)).catch(() => {}); }, []);

  const setFilter = (k, v) => { setPage(0); setF((p) => ({ ...p, [k]: v })); };

  const remove = async (item) => {
    if (!confirm(`Delete "${item.title}"?`)) return;
    try { await api.delete(`/feedback/${item.id}`); load(); } catch (e) { setError(errMsg(e)); }
  };
  const reanalyze = async (item) => {
    try { await api.post(`/feedback/${item.id}/analyze`); load(); } catch (e) { setError(errMsg(e)); }
  };
  const save = async (values) => {
    setEditErr("");
    try {
      await api.put(`/feedback/${edit.id}`, values);
      setEdit(null);
      load();
    } catch (e) { setEditErr(errMsg(e)); }
  };

  const pages = Math.max(1, Math.ceil(total / LIMIT));

  return (
    <div>
      <div className="card mb-4 grid gap-3 sm:grid-cols-3">
        <div className="relative">
          <Search size={16} className="absolute left-3 top-2.5 text-slate-400" />
          <input className="input pl-9" placeholder="Search feedback" value={f.search} onChange={(e) => setFilter("search", e.target.value)} />
        </div>
        <select className="input" value={f.sentiment} onChange={(e) => setFilter("sentiment", e.target.value)}>
          <option value="">All sentiments</option>
          <option value="positive">Positive</option>
          <option value="neutral">Neutral</option>
          <option value="negative">Negative</option>
        </select>
        <select className="input" value={f.category_id} onChange={(e) => setFilter("category_id", e.target.value)}>
          <option value="">All categories</option>
          {cats.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </div>

      <ErrorBox>{error}</ErrorBox>
      <div className="card overflow-x-auto p-0">
        {loading ? <Spinner /> : items.length === 0 ? <Empty>No feedback found.</Empty> : (
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 text-slate-500">
              <tr>
                <th className="px-4 py-3 font-medium">Feedback</th>
                {admin && <th className="px-4 py-3 font-medium">User</th>}
                <th className="px-4 py-3 font-medium">Category</th>
                <th className="px-4 py-3 font-medium">Rating</th>
                <th className="px-4 py-3 font-medium">Sentiment</th>
                <th className="px-4 py-3 font-medium">Date</th>
                <th className="px-4 py-3 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {items.map((i) => (
                <tr key={i.id} className="hover:bg-slate-50">
                  <td className="max-w-xs px-4 py-3">
                    <button className="text-left font-medium text-sky-700 hover:underline" onClick={() => setView(i)}>{i.title}</button>
                    <p className="truncate text-slate-500">{i.message}</p>
                  </td>
                  {admin && <td className="px-4 py-3">{i.user_name}</td>}
                  <td className="px-4 py-3">{i.category_name}</td>
                  <td className="px-4 py-3"><Stars value={i.rating} size={14} /></td>
                  <td className="px-4 py-3"><SentimentBadge sentiment={i.sentiment?.sentiment} /></td>
                  <td className="whitespace-nowrap px-4 py-3 text-slate-500">
                    <div>{fmtDate(i.created_at)}</div>
                    {i.updated_at && i.updated_at !== i.created_at && (
                      <div className="text-[11px] text-sky-600 font-medium">Updated: {fmtDate(i.updated_at)}</div>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex justify-end gap-1">
                      {!i.sentiment && <button className="btn-secondary px-2" title="Re-analyze" onClick={() => reanalyze(i)}><RefreshCw size={14} /></button>}
                      <button className="btn-secondary px-2" title="Edit" onClick={() => { setEditErr(""); setEdit(i); }}><Pencil size={14} /></button>
                      <button className="btn-danger px-2" title="Delete" onClick={() => remove(i)}><Trash2 size={14} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="mt-4 flex items-center justify-between text-sm text-slate-500">
        <span>{total} result{total === 1 ? "" : "s"}</span>
        <div className="flex items-center gap-2">
          <button className="btn-secondary px-2" disabled={page === 0} onClick={() => setPage(page - 1)}><ChevronLeft size={16} /></button>
          <span>Page {page + 1} of {pages}</span>
          <button className="btn-secondary px-2" disabled={page + 1 >= pages} onClick={() => setPage(page + 1)}><ChevronRight size={16} /></button>
        </div>
      </div>

      {view && (
        <Modal title={view.title} onClose={() => setView(null)}>
          <div className="mb-3 flex flex-wrap items-center gap-3 text-sm text-slate-500">
            <Stars value={view.rating} /> <span>{view.category_name}</span> <span>Submitted: {fmtDate(view.created_at)}</span>
            {view.updated_at && view.updated_at !== view.created_at && (
              <span className="font-medium text-sky-600">Updated: {fmtDate(view.updated_at)}</span>
            )}
            {admin && <span>by {view.user_name}</span>}
          </div>
          <p className="mb-4 whitespace-pre-wrap text-sm">{view.message}</p>
          {view.sentiment ? (
            <div className="rounded-xl bg-slate-50 p-4">
              <div className="mb-3 flex items-center justify-between">
                <SentimentBadge sentiment={view.sentiment.sentiment} />
                <span className="text-xs text-slate-500">Confidence {(view.sentiment.confidence * 100).toFixed(0)}%</span>
              </div>
              <ScoreBars s={view.sentiment} />
            </div>
          ) : <p className="text-sm text-slate-500">Sentiment analysis is pending.</p>}
        </Modal>
      )}
      {edit && (
        <Modal title="Edit feedback" onClose={() => setEdit(null)}>
          <FeedbackForm categories={cats} error={editErr} submitLabel="Save changes" onSubmit={save}
            initial={{ title: edit.title, message: edit.message, category_id: String(edit.category_id), rating: edit.rating }} />
        </Modal>
      )}
    </div>
  );
}
