import { Loader2, Star, X } from "lucide-react";

export const SENTIMENT = {
  positive: { label: "Positive", badge: "bg-green-100 text-green-700", bar: "bg-green-400", color: "#4ade80" },
  negative: { label: "Negative", badge: "bg-red-100 text-red-700", bar: "bg-red-400", color: "#f87171" },
  neutral: { label: "Neutral", badge: "bg-orange-100 text-orange-700", bar: "bg-orange-400", color: "#fb923c" },
};

export const fmtDate = (d) =>
  d ? new Date(d + (String(d).endsWith("Z") ? "" : "Z")).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" }) : "";

export function SentimentBadge({ sentiment }) {
  if (!sentiment) return <span className="rounded-full bg-slate-100 px-2.5 py-0.5 text-xs font-medium text-slate-500">Pending</span>;
  const s = SENTIMENT[sentiment];
  return <span className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${s.badge}`}>{s.label}</span>;
}

export function Stars({ value, size = 16 }) {
  return (
    <span className="inline-flex gap-0.5" aria-label={`${value} out of 5`}>
      {[1, 2, 3, 4, 5].map((n) => (
        <Star key={n} size={size} className={n <= Math.round(value) ? "fill-amber-400 text-amber-400" : "text-slate-300"} />
      ))}
    </span>
  );
}

export function StarInput({ value, onChange }) {
  return (
    <div className="flex gap-1">
      {[1, 2, 3, 4, 5].map((n) => (
        <button type="button" key={n} onClick={() => onChange(n)} aria-label={`${n} stars`}>
          <Star size={30} className={n <= value ? "fill-amber-400 text-amber-400" : "text-slate-300 hover:text-amber-300"} />
        </button>
      ))}
    </div>
  );
}

export function StatCard({ label, value, icon: Icon, tone = "sky" }) {
  const tones = {
    sky: "bg-sky-100 text-sky-600", green: "bg-green-100 text-green-600", red: "bg-red-100 text-red-600",
    orange: "bg-orange-100 text-orange-600", amber: "bg-amber-100 text-amber-600", slate: "bg-slate-100 text-slate-600",
  };
  return (
    <div className="card flex items-center gap-4">
      <div className={`rounded-xl p-3 ${tones[tone]}`}>{Icon && <Icon size={22} />}</div>
      <div>
        <p className="text-2xl font-semibold">{value}</p>
        <p className="text-sm text-slate-500">{label}</p>
      </div>
    </div>
  );
}

export function PageHeader({ title, subtitle, action }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-2xl font-semibold">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-slate-500">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

export const Spinner = () => (
  <div className="flex justify-center py-16 text-sky-500"><Loader2 className="animate-spin" /></div>
);

export const ErrorBox = ({ children }) =>
  children ? <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-2 text-sm text-red-700">{children}</div> : null;

export const Empty = ({ children }) => <p className="py-10 text-center text-sm text-slate-500">{children}</p>;

export function Modal({ title, onClose, children }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/30 p-4" onClick={onClose}>
      <div className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-2xl bg-white p-6 shadow-xl" onClick={(e) => e.stopPropagation()}>
        <div className="mb-4 flex items-start justify-between gap-4">
          <h2 className="text-lg font-semibold">{title}</h2>
          <button onClick={onClose} aria-label="Close" className="text-slate-400 hover:text-slate-600"><X size={20} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function ScoreBars({ s }) {
  const rows = [["positive", s.positive_score], ["neutral", s.neutral_score], ["negative", s.negative_score]];
  return (
    <div className="space-y-2">
      {rows.map(([k, v]) => (
        <div key={k}>
          <div className="mb-0.5 flex justify-between text-xs text-slate-500"><span>{SENTIMENT[k].label}</span><span>{(v * 100).toFixed(0)}%</span></div>
          <div className="h-2 rounded-full bg-slate-100"><div className={`h-2 rounded-full ${SENTIMENT[k].bar}`} style={{ width: `${v * 100}%` }} /></div>
        </div>
      ))}
    </div>
  );
}
