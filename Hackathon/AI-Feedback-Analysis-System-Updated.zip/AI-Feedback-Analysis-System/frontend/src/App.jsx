import { Navigate, Outlet, Route, Routes } from "react-router-dom";
import { useAuth } from "./AuthContext.jsx";
import Navbar from "./components/Navbar.jsx";
import { Spinner } from "./components/ui.jsx";
import Landing from "./pages/Landing.jsx";
import Login from "./pages/Login.jsx";
import Register from "./pages/Register.jsx";
import UserDashboard from "./pages/UserDashboard.jsx";
import SubmitFeedback from "./pages/SubmitFeedback.jsx";
import FeedbackHistory from "./pages/FeedbackHistory.jsx";
import AdminDashboard from "./pages/AdminDashboard.jsx";
import FeedbackManagement from "./pages/FeedbackManagement.jsx";
import CategoryManagement from "./pages/CategoryManagement.jsx";
import Reports from "./pages/Reports.jsx";
import UserManagement from "./pages/UserManagement.jsx";

function Protected({ role }) {
  const { user, loading } = useAuth();
  if (loading) return <Spinner />;
  if (!user) return <Navigate to="/login" replace />;
  if (role && user.role !== role) return <Navigate to={user.role === "admin" ? "/admin" : "/dashboard"} replace />;
  return <Outlet />;
}

export default function App() {
  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="mx-auto max-w-6xl px-4 py-8">
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route element={<Protected />}>
            <Route path="/submit" element={<SubmitFeedback />} />
          </Route>
          <Route element={<Protected role="user" />}>
            <Route path="/dashboard" element={<UserDashboard />} />
            <Route path="/history" element={<FeedbackHistory />} />
          </Route>
          <Route element={<Protected role="admin" />}>
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/admin/feedback" element={<FeedbackManagement />} />
            <Route path="/admin/categories" element={<CategoryManagement />} />
            <Route path="/admin/reports" element={<Reports />} />
            <Route path="/admin/users" element={<UserManagement />} />
          </Route>
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </div>
  );
}
