from datetime import datetime

from sqlalchemy import CheckConstraint, Column, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship

from .database import Base


def utcnow():
    return datetime.utcnow()


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    email = Column(String(255), unique=True, nullable=False, index=True)
    hashed_password = Column(String(255), nullable=False)
    role = Column(String(20), nullable=False, default="user")
    created_at = Column(DateTime, nullable=False, default=utcnow)
    __table_args__ = (CheckConstraint("role IN ('user','admin')", name="ck_users_role"),)

    feedbacks = relationship("Feedback", back_populates="user", cascade="all, delete-orphan")
    reports = relationship("Report", back_populates="generator", cascade="all, delete-orphan")


class Category(Base):
    __tablename__ = "categories"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), unique=True, nullable=False)
    description = Column(String(500))

    feedbacks = relationship("Feedback", back_populates="category")


class Feedback(Base):
    __tablename__ = "feedback"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    category_id = Column(Integer, ForeignKey("categories.id", ondelete="RESTRICT"), nullable=False, index=True)
    title = Column(String(150), nullable=False)
    message = Column(Text, nullable=False)
    rating = Column(Integer, nullable=False)
    created_at = Column(DateTime, nullable=False, default=utcnow, index=True)
    updated_at = Column(DateTime, nullable=True, default=utcnow, onupdate=utcnow)
    __table_args__ = (CheckConstraint("rating BETWEEN 1 AND 5", name="ck_feedback_rating"),)

    user = relationship("User", back_populates="feedbacks")
    category = relationship("Category", back_populates="feedbacks")
    sentiment = relationship("SentimentResult", back_populates="feedback", uselist=False,
                             cascade="all, delete-orphan")


class SentimentResult(Base):
    __tablename__ = "sentiment_results"
    id = Column(Integer, primary_key=True)
    feedback_id = Column(Integer, ForeignKey("feedback.id", ondelete="CASCADE"), unique=True, nullable=False)
    sentiment = Column(String(20), nullable=False)
    confidence = Column(Float, nullable=False)
    positive_score = Column(Float, nullable=False)
    negative_score = Column(Float, nullable=False)
    neutral_score = Column(Float, nullable=False)
    analyzed_at = Column(DateTime, nullable=False, default=utcnow)
    __table_args__ = (CheckConstraint("sentiment IN ('positive','negative','neutral')", name="ck_sentiment_label"),)

    feedback = relationship("Feedback", back_populates="sentiment")


class Report(Base):
    __tablename__ = "reports"
    id = Column(Integer, primary_key=True)
    generated_by = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    report_type = Column(String(50), nullable=False)
    created_at = Column(DateTime, nullable=False, default=utcnow)

    generator = relationship("User", back_populates="reports")
