import re
from datetime import date, datetime, timedelta

from sqlalchemy import case, func
from sqlalchemy.orm import Session, joinedload

from .models import Category, Feedback, SentimentResult, User

LABELS = ("positive", "negative", "neutral")


def _sent_sum(label):
    return func.coalesce(func.sum(case((SentimentResult.sentiment == label, 1), else_=0)), 0)


def overview(db: Session, user_id: int | None = None) -> dict:
    fq = db.query(func.count(Feedback.id), func.avg(Feedback.rating))
    if user_id:
        fq = fq.filter(Feedback.user_id == user_id)
    total, avg = fq.one()
    counts = sentiment_stats(db, user_id)
    out = {"total_feedback": total or 0, "average_rating": round(float(avg), 2) if avg else 0.0,
           "positive": counts["positive"], "negative": counts["negative"], "neutral": counts["neutral"],
           "analyzed": sum(counts[k] for k in LABELS)}
    if user_id is None:
        out["total_users"] = db.query(func.count(User.id)).scalar() or 0
    return out


def sentiment_stats(db: Session, user_id: int | None = None) -> dict:
    q = db.query(SentimentResult.sentiment, func.count(SentimentResult.id)).join(
        Feedback, Feedback.id == SentimentResult.feedback_id)
    if user_id:
        q = q.filter(Feedback.user_id == user_id)
    rows = {label: n for label, n in q.group_by(SentimentResult.sentiment).all()}
    return {k: rows.get(k, 0) for k in LABELS}


def rating_stats(db: Session) -> dict:
    rows = {r: n for r, n in db.query(Feedback.rating, func.count(Feedback.id)).group_by(Feedback.rating).all()}
    avg = db.query(func.avg(Feedback.rating)).scalar()
    return {"average": round(float(avg), 2) if avg else 0.0,
            "distribution": [{"rating": r, "count": rows.get(r, 0)} for r in range(1, 6)]}


def category_stats(db: Session) -> list:
    q = (db.query(Category.id, Category.name, func.count(func.distinct(Feedback.id)), func.avg(Feedback.rating),
                  _sent_sum("positive"), _sent_sum("negative"), _sent_sum("neutral"))
         .outerjoin(Feedback, Feedback.category_id == Category.id)
         .outerjoin(SentimentResult, SentimentResult.feedback_id == Feedback.id)
         .group_by(Category.id, Category.name).order_by(Category.name))
    return [{"category_id": i, "category": n, "total": t or 0, "average_rating": round(float(a), 2) if a else 0.0,
             "positive": int(p), "negative": int(ng), "neutral": int(nu)} for i, n, t, a, p, ng, nu in q.all()]


def trends(db: Session, days: int = 30) -> list:
    start = date.today() - timedelta(days=days - 1)
    day = func.date(Feedback.created_at)
    rows = (db.query(day, func.count(Feedback.id), _sent_sum("positive"), _sent_sum("negative"), _sent_sum("neutral"))
            .outerjoin(SentimentResult, SentimentResult.feedback_id == Feedback.id)
            .filter(Feedback.created_at >= datetime.combine(start, datetime.min.time()))
            .group_by(day).order_by(day).all())
    by_day = {str(d): (t, int(p), int(n), int(u)) for d, t, p, n, u in rows}
    out = []
    for i in range(days):
        d = str(start + timedelta(days=i))
        t, p, n, u = by_day.get(d, (0, 0, 0, 0))
        out.append({"date": d, "total": t, "positive": p, "negative": n, "neutral": u})
    return out


COMPLAINT_KEYWORDS = [
    ("broken", "Hardware / Equipment Issue"),
    ("wifi", "Network / Wi-Fi Problems"),
    ("slow", "Slow Support / Response"),
    ("poor", "Poor Service Quality"),
    ("bad", "Subpar Overall Experience"),
    ("terrible", "Severe Dissatisfaction"),
    ("crowded", "Classroom / Space Crowding"),
    ("noisy", "Noisy / Distracting Environment"),
    ("disappointed", "Expectations Not Met"),
    ("delay", "Unreasonable Delay"),
    ("unhelpful", "Unhelpful Assistance"),
    ("dirty", "Maintenance / Cleanliness"),
    ("frustrating", "Frustrating Process"),
    ("boring", "Unengaging Content"),
    ("confusing", "Unclear Instructions"),
]


def common_complaints(db: Session, limit: int = 6) -> list:
    """Analyze negative or low-rated feedback to surface recurring complaints with counts and sample."""
    negative_rows = (
        db.query(Feedback)
        .options(joinedload(Feedback.category))
        .outerjoin(SentimentResult, SentimentResult.feedback_id == Feedback.id)
        .filter((SentimentResult.sentiment == "negative") | (Feedback.rating <= 2))
        .all()
    )
    if not negative_rows:
        return []

    counts = {}
    samples = {}
    categories = {}
    for fb in negative_rows:
        full_text = f"{fb.title} {fb.message}".lower()
        cat_name = fb.category.name if fb.category else "General"
        for kw, issue in COMPLAINT_KEYWORDS:
            if re.search(r"\b" + re.escape(kw) + r"\b", full_text):
                counts[issue] = counts.get(issue, 0) + 1
                if issue not in samples:
                    samples[issue] = fb.title
                    categories[issue] = cat_name

    sorted_issues = sorted(counts.items(), key=lambda x: x[1], reverse=True)[:limit]
    return [
        {
            "issue": issue,
            "count": count,
            "category": categories.get(issue, "General"),
            "sample_feedback": samples.get(issue, ""),
        }
        for issue, count in sorted_issues
    ]


SUGGESTION_TRIGGERS = [
    "suggest", "recommend", "should", "could", "improve", "need", "wish", "hope", "would like", "please"
]


def suggestion_analysis(db: Session, limit: int = 10) -> list:
    """Identify constructive feedback items containing actionable suggestions."""
    rows = (
        db.query(Feedback)
        .options(joinedload(Feedback.category), joinedload(Feedback.user))
        .order_by(Feedback.created_at.desc())
        .all()
    )
    results = []
    for fb in rows:
        text = f"{fb.title} {fb.message}".lower()
        for trig in SUGGESTION_TRIGGERS:
            if trig in text:
                results.append({
                    "id": fb.id,
                    "title": fb.title,
                    "message": fb.message,
                    "category": fb.category.name if fb.category else "General",
                    "user_name": fb.user.name if fb.user else "Anonymous",
                    "rating": fb.rating,
                    "created_at": fb.created_at.isoformat(),
                    "trigger_keyword": trig,
                })
                break
        if len(results) >= limit:
            break
    return results

