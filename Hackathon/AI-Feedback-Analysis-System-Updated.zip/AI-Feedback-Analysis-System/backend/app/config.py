import os
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:  # optional
    pass

PROJECT_ROOT = Path(__file__).resolve().parents[2]


class Settings:
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-change-me-feedback-iq-secret-key-32b-secure")
    ALGORITHM = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "480"))
    DATABASE_URL = os.getenv("DATABASE_URL") or f"sqlite:///{(PROJECT_ROOT / 'database' / 'feedback.db').as_posix()}"
    AI_SERVICE_URL = os.getenv("AI_SERVICE_URL", "http://localhost:8001").rstrip("/")
    AI_TIMEOUT = float(os.getenv("AI_TIMEOUT", "5"))
    CORS_ORIGINS = [o.strip() for o in os.getenv("CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173").split(",")]
    ADMIN_NAME = os.getenv("ADMIN_NAME", "Administrator")
    ADMIN_EMAIL = os.getenv("ADMIN_EMAIL", "admin@feedback.com").lower()
    ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "Admin@123")


settings = Settings()
