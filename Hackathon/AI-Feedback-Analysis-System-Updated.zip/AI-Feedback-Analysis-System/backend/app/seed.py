"""Default data + optional demo data.   Usage: python -m app.seed --demo   (run from backend/)"""
import random
import sys
from datetime import timedelta

from .config import settings
from .database import Base, SessionLocal, engine
from .models import Category, Feedback, User, utcnow
from .security import hash_password
from .services import run_analysis

DEFAULT_CATEGORIES = [
    ("Teaching & Faculty", "Classroom teaching, faculty support and course content"),
    ("Facilities", "Campus, labs, library, cafeteria and infrastructure"),
    ("Customer Service", "Support, responsiveness and staff behaviour"),
    ("Product Quality", "Quality, reliability and value of products or services"),
    ("Workplace", "Work environment, management and culture"),
    ("Other", "Anything else"),
]

DEMO = [
    ("Excellent teaching", "Excellent teaching and very helpful faculty. The lectures were engaging.", 5, 0),
    ("Lab equipment is broken", "Very poor service and bad experience. Several computers were broken and nobody helped.", 1, 0),
    ("Cafeteria is average", "The service is average.", 3, 1),
    ("Great library", "The library is clean, quiet and the staff is friendly and professional.", 5, 1),
    ("Slow support", "Support was slow and unhelpful. I am disappointed with the response time.", 2, 2),
    ("Wonderful workplace", "Amazing team culture, I love working here. Management is supportive.", 5, 3),
    ("Wifi problems", "The wifi is terrible and keeps disconnecting. Really frustrating.", 1, 3),
    ("Product works fine", "The product is okay, nothing special.", 3, 4),
    ("Smooth checkout", "Fast delivery and a smooth, easy checkout. Highly recommend.", 5, 5),
    ("Not happy", "I am not happy with the quality. It was worse than expected.", 2, 6),
    ("Helpful staff", "The staff was polite, knowledgeable and helpful.", 4, 7),
    ("Crowded classrooms", "Classrooms are crowded and noisy, which makes learning difficult.", 2, 8),
    ("Good course content", "The course content is useful and well organised. Good experience.", 4, 9),
    ("Standard service", "The service was standard. Neither good nor bad.", 3, 10),
]


def ensure_defaults(db):
    if not db.query(User).filter(User.email == settings.ADMIN_EMAIL).first():
        db.add(User(name=settings.ADMIN_NAME, email=settings.ADMIN_EMAIL,
                    hashed_password=hash_password(settings.ADMIN_PASSWORD), role="admin"))
    if db.query(Category).count() == 0:
        db.add_all([Category(name=n, description=d) for n, d in DEFAULT_CATEGORIES])
    db.commit()


def seed_demo(db):
    user = db.query(User).filter(User.email == "student@feedback.com").first()
    if not user:
        user = User(name="Demo Student", email="student@feedback.com", hashed_password=hash_password("Student@123"), role="user")
        db.add(user)
        db.commit()
    if db.query(Feedback).filter(Feedback.user_id == user.id).count():
        print("Demo data already present.")
        return
    cats = db.query(Category).all()
    failed = 0
    for title, msg, rating, days_ago in DEMO:
        fb = Feedback(user_id=user.id, category_id=random.choice(cats).id, title=title, message=msg, rating=rating,
                      created_at=utcnow() - timedelta(days=days_ago, hours=random.randint(0, 5)))
        db.add(fb)
        db.commit()
        db.refresh(fb)
        if not run_analysis(db, fb):
            failed += 1
    print(f"Seeded {len(DEMO)} demo feedback items for student@feedback.com / Student@123")
    if failed:
        print(f"WARNING: {failed} items not analyzed (AI service down). Start it and use 'Re-analyze' in the admin panel.")


if __name__ == "__main__":
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as session:
        ensure_defaults(session)
        if "--demo" in sys.argv:
            seed_demo(session)
        print("Defaults ready. Admin:", settings.ADMIN_EMAIL)
