import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import text

from . import ai_client
from .config import settings
from .database import Base, SessionLocal, engine
from .routers import analytics, auth, categories, feedback, reports, users
from .seed import ensure_defaults

logging.basicConfig(level=logging.INFO)


@asynccontextmanager
async def lifespan(_: FastAPI):
    Base.metadata.create_all(bind=engine)
    try:
        with engine.begin() as conn:
            cols = [r[1] for r in conn.execute(text("PRAGMA table_info(feedback)")).fetchall()]
            if cols and "updated_at" not in cols:
                conn.execute(text("ALTER TABLE feedback ADD COLUMN updated_at DATETIME"))
    except Exception as exc:
        logging.warning("Migration check error: %s", exc)
    with SessionLocal() as db:
        ensure_defaults(db)
    yield


app = FastAPI(title="AI-Based Feedback Analysis System", version="1.0.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=settings.CORS_ORIGINS, allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])

for r in (auth.router, feedback.router, categories.router, analytics.router, reports.router, users.router):
    app.include_router(r)


@app.get("/api/health", tags=["Health"])
def health():
    try:
        with SessionLocal() as db:
            db.execute(text("SELECT 1"))
        db_status = "ok"
    except Exception as exc:
        db_status = f"error: {exc}"
    ai = ai_client.health()
    return {"status": "ok" if db_status == "ok" else "degraded", "database": db_status, "ai_service": ai}
