from sqlalchemy.orm import Session

from . import ai_client
from .models import Feedback, SentimentResult, utcnow


def run_analysis(db: Session, fb: Feedback) -> bool:
    """Analyze a feedback item via the AI service and store/replace the result. Never raises."""
    res = ai_client.analyze(f"{fb.title}. {fb.message}")
    if not res:
        return False
    try:
        row = db.query(SentimentResult).filter(SentimentResult.feedback_id == fb.id).first()
        if not row:
            row = SentimentResult(feedback_id=fb.id)
            db.add(row)
        row.sentiment = res["sentiment"]
        row.confidence = res["confidence"]
        row.positive_score = res["positive_score"]
        row.negative_score = res["negative_score"]
        row.neutral_score = res["neutral_score"]
        row.analyzed_at = utcnow()
        db.commit()
        db.refresh(fb)
        return True
    except Exception:
        db.rollback()
        return False


def serialize_feedback(f: Feedback) -> dict:
    s = f.sentiment
    return {
        "id": f.id, "user_id": f.user_id, "user_name": f.user.name if f.user else None,
        "category_id": f.category_id, "category_name": f.category.name if f.category else None,
        "title": f.title, "message": f.message, "rating": f.rating,
        "created_at": f.created_at, "updated_at": f.updated_at,
        "sentiment": None if not s else {
            "sentiment": s.sentiment, "confidence": s.confidence, "positive_score": s.positive_score,
            "negative_score": s.negative_score, "neutral_score": s.neutral_score, "analyzed_at": s.analyzed_at},
        "analysis_status": "completed" if s else "pending",
    }
