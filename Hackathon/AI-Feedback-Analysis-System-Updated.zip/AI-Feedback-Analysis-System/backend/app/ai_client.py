"""HTTP client for the separate AI sentiment microservice (CO4)."""
import logging
from typing import Optional

import httpx

from .config import settings

log = logging.getLogger("ai_client")


def analyze(text: str) -> Optional[dict]:
    """Returns the sentiment dict, or None when the AI service is unreachable/failing."""
    try:
        r = httpx.post(f"{settings.AI_SERVICE_URL}/analyze", json={"text": text}, timeout=settings.AI_TIMEOUT)
        r.raise_for_status()
        return r.json()
    except Exception as exc:
        log.warning("AI service call failed: %s", exc)
        return None


def health() -> dict:
    try:
        r = httpx.get(f"{settings.AI_SERVICE_URL}/health", timeout=2)
        r.raise_for_status()
        return {"status": "ok", **r.json()}
    except Exception as exc:
        return {"status": "unavailable", "detail": str(exc)}
