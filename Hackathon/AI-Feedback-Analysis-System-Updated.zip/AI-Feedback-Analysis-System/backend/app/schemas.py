from datetime import datetime
from typing import List, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator

EMAIL_RE = r"^[^@\s]+@[^@\s]+\.[^@\s]+$"


class RegisterIn(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    email: str = Field(pattern=EMAIL_RE, max_length=255)
    password: str = Field(min_length=6, max_length=72)

    @field_validator("email")
    @classmethod
    def _lower(cls, v):
        return v.strip().lower()


class LoginIn(BaseModel):
    email: str
    password: str

    @field_validator("email")
    @classmethod
    def _lower(cls, v):
        return v.strip().lower()


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    email: str
    role: str
    created_at: datetime


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


class CategoryIn(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    description: Optional[str] = Field(default=None, max_length=500)


class CategoryOut(BaseModel):
    id: int
    name: str
    description: Optional[str] = None
    feedback_count: int = 0


class FeedbackIn(BaseModel):
    title: str = Field(min_length=3, max_length=150)
    message: str = Field(min_length=5, max_length=5000)
    category_id: int
    rating: int = Field(ge=1, le=5)


class FeedbackUpdate(BaseModel):
    title: Optional[str] = Field(default=None, min_length=3, max_length=150)
    message: Optional[str] = Field(default=None, min_length=5, max_length=5000)
    category_id: Optional[int] = None
    rating: Optional[int] = Field(default=None, ge=1, le=5)


class SentimentOut(BaseModel):
    sentiment: str
    confidence: float
    positive_score: float
    negative_score: float
    neutral_score: float
    analyzed_at: datetime


class FeedbackOut(BaseModel):
    id: int
    user_id: int
    user_name: Optional[str] = None
    category_id: int
    category_name: Optional[str] = None
    title: str
    message: str
    rating: int
    created_at: datetime
    updated_at: Optional[datetime] = None
    sentiment: Optional[SentimentOut] = None
    analysis_status: Literal["completed", "pending"]


class FeedbackListOut(BaseModel):
    items: List[FeedbackOut]
    total: int


class ReportIn(BaseModel):
    report_type: Literal["summary", "sentiment", "category", "trends", "complaints", "suggestions"]


class ReportOut(BaseModel):
    id: int
    report_type: str
    generated_by: int
    created_at: datetime


class UserDetailOut(BaseModel):
    id: int
    name: str
    email: str
    role: str
    created_at: datetime
    feedback_count: int = 0


class UserRoleUpdate(BaseModel):
    role: Literal["user", "admin"]

