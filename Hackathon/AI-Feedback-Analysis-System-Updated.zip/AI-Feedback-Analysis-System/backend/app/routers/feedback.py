from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session, joinedload, selectinload

from ..database import get_db
from ..deps import get_current_user
from ..models import Category, Feedback, SentimentResult, User, utcnow
from ..schemas import FeedbackIn, FeedbackListOut, FeedbackOut, FeedbackUpdate
from ..services import run_analysis, serialize_feedback

router = APIRouter(prefix="/api/feedback", tags=["Feedback"])


def _get_accessible(db: Session, fid: int, user: User) -> Feedback:
    """Users only see their own feedback; admins see everything. Others get 404 (no existence leak)."""
    fb = db.query(Feedback).populate_existing().options(joinedload(Feedback.user), joinedload(Feedback.category),
                                    selectinload(Feedback.sentiment)).filter(Feedback.id == fid).first()
    if not fb or (user.role != "admin" and fb.user_id != user.id):
        raise HTTPException(404, "Feedback not found")
    return fb


def _check_category(db: Session, category_id: int):
    if not db.get(Category, category_id):
        raise HTTPException(400, "Selected category does not exist")


@router.post("", response_model=FeedbackOut, status_code=201)
def create_feedback(data: FeedbackIn, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    _check_category(db, data.category_id)
    fb = Feedback(user_id=user.id, updated_at=utcnow(), **data.model_dump())
    db.add(fb)
    db.commit()
    db.refresh(fb)
    run_analysis(db, fb)          # automatic sentiment analysis; failure leaves status "pending"
    return serialize_feedback(_get_accessible(db, fb.id, user))


@router.get("", response_model=FeedbackListOut)
def list_feedback(sentiment: Optional[str] = Query(None, pattern="^(positive|negative|neutral)$"),
                  category_id: Optional[int] = None, rating: Optional[int] = Query(None, ge=1, le=5),
                  search: Optional[str] = None, skip: int = Query(0, ge=0), limit: int = Query(20, ge=1, le=100),
                  db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    q = db.query(Feedback)
    if user.role != "admin":
        q = q.filter(Feedback.user_id == user.id)
    if sentiment:
        q = q.join(SentimentResult, SentimentResult.feedback_id == Feedback.id).filter(SentimentResult.sentiment == sentiment)
    if category_id:
        q = q.filter(Feedback.category_id == category_id)
    if rating:
        q = q.filter(Feedback.rating == rating)
    if search:
        like = f"%{search.strip()}%"
        q = q.filter(Feedback.title.ilike(like) | Feedback.message.ilike(like))
    total = q.count()
    rows = (q.options(joinedload(Feedback.user), joinedload(Feedback.category), selectinload(Feedback.sentiment))
            .order_by(Feedback.created_at.desc(), Feedback.id.desc()).offset(skip).limit(limit).all())
    return {"items": [serialize_feedback(f) for f in rows], "total": total}


@router.get("/{feedback_id}", response_model=FeedbackOut)
def get_feedback(feedback_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return serialize_feedback(_get_accessible(db, feedback_id, user))


@router.put("/{feedback_id}", response_model=FeedbackOut)
def update_feedback(feedback_id: int, data: FeedbackUpdate, db: Session = Depends(get_db),
                    user: User = Depends(get_current_user)):
    fb = _get_accessible(db, feedback_id, user)
    changes = data.model_dump(exclude_unset=True, exclude_none=True)
    if "category_id" in changes:
        _check_category(db, changes["category_id"])
    text_changed = any(k in changes and changes[k] != getattr(fb, k) for k in ("title", "message"))
    for k, v in changes.items():
        setattr(fb, k, v)
    fb.updated_at = utcnow()
    db.commit()
    if text_changed or not fb.sentiment:
        run_analysis(db, fb)
    return serialize_feedback(_get_accessible(db, feedback_id, user))


@router.delete("/{feedback_id}", status_code=204)
def delete_feedback(feedback_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    fb = _get_accessible(db, feedback_id, user)
    db.delete(fb)
    db.commit()


@router.post("/{feedback_id}/analyze", response_model=FeedbackOut)
def reanalyze(feedback_id: int, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    fb = _get_accessible(db, feedback_id, user)
    if not run_analysis(db, fb):
        raise HTTPException(503, "AI sentiment service is currently unavailable. Try again shortly.")
    return serialize_feedback(_get_accessible(db, feedback_id, user))
