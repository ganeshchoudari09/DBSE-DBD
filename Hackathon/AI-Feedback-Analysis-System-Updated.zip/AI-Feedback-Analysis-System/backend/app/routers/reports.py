import csv
import io
from datetime import datetime

from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session, joinedload, selectinload

from .. import stats
from ..database import get_db
from ..deps import require_admin
from ..models import Feedback, Report, User
from ..schemas import ReportIn, ReportOut

router = APIRouter(prefix="/api/reports", tags=["Reports"])


@router.post("/generate")
def generate(data: ReportIn, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    t = data.report_type
    if t == "summary":
        body = {"overview": stats.overview(db), "ratings": stats.rating_stats(db)["distribution"]}
    elif t == "sentiment":
        body = stats.sentiment_stats(db)
    elif t == "category":
        body = stats.category_stats(db)
    elif t == "complaints":
        body = stats.common_complaints(db)
    elif t == "suggestions":
        body = stats.suggestion_analysis(db)
    else:
        body = stats.trends(db, 30)
    rep = Report(generated_by=admin.id, report_type=t)
    db.add(rep)
    db.commit()
    db.refresh(rep)
    return {"id": rep.id, "report_type": t, "generated_at": rep.created_at, "data": body}


@router.get("", response_model=list[ReportOut])
def list_reports(db: Session = Depends(get_db), _: User = Depends(require_admin)):
    return db.query(Report).order_by(Report.created_at.desc()).limit(50).all()


@router.get("/export")
def export_csv(db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    rows = (db.query(Feedback).options(joinedload(Feedback.user), joinedload(Feedback.category),
                                       selectinload(Feedback.sentiment)).order_by(Feedback.id).all())
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["id", "user", "email", "category", "title", "message", "rating", "sentiment", "confidence",
                "positive_score", "negative_score", "neutral_score", "created_at", "updated_at"])
    for f in rows:
        s = f.sentiment
        w.writerow([f.id, f.user.name, f.user.email, f.category.name, f.title, f.message, f.rating,
                    s.sentiment if s else "", s.confidence if s else "", s.positive_score if s else "",
                    s.negative_score if s else "", s.neutral_score if s else "",
                    f.created_at.isoformat() if f.created_at else "",
                    f.updated_at.isoformat() if f.updated_at else ""])
    db.add(Report(generated_by=admin.id, report_type="csv_export"))
    db.commit()
    buf.seek(0)
    name = f"feedback_export_{datetime.utcnow():%Y%m%d_%H%M%S}.csv"
    return StreamingResponse(iter([buf.getvalue()]), media_type="text/csv",
                             headers={"Content-Disposition": f'attachment; filename="{name}"'})
