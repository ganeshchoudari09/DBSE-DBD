from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import require_admin
from ..models import Feedback, User
from ..schemas import UserDetailOut, UserRoleUpdate

router = APIRouter(prefix="/api/users", tags=["Users"])


@router.get("", response_model=list[UserDetailOut])
def list_users(db: Session = Depends(get_db), _: User = Depends(require_admin)):
    rows = (
        db.query(User, func.count(Feedback.id).label("cnt"))
        .outerjoin(Feedback, Feedback.user_id == User.id)
        .group_by(User.id)
        .order_by(User.created_at.desc())
        .all()
    )
    return [
        UserDetailOut(
            id=u.id,
            name=u.name,
            email=u.email,
            role=u.role,
            created_at=u.created_at,
            feedback_count=cnt or 0,
        )
        for u, cnt in rows
    ]


@router.put("/{user_id}/role", response_model=UserDetailOut)
def update_user_role(user_id: int, data: UserRoleUpdate, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    target = db.get(User, user_id)
    if not target:
        raise HTTPException(404, "User not found")
    if target.id == admin.id and data.role != "admin":
        raise HTTPException(400, "Cannot change your own admin role")
    target.role = data.role
    db.commit()
    db.refresh(target)
    cnt = db.query(func.count(Feedback.id)).filter(Feedback.user_id == target.id).scalar() or 0
    return UserDetailOut(
        id=target.id,
        name=target.name,
        email=target.email,
        role=target.role,
        created_at=target.created_at,
        feedback_count=cnt,
    )


@router.delete("/{user_id}", status_code=204)
def delete_user(user_id: int, db: Session = Depends(get_db), admin: User = Depends(require_admin)):
    target = db.get(User, user_id)
    if not target:
        raise HTTPException(404, "User not found")
    if target.id == admin.id:
        raise HTTPException(400, "Cannot delete your own account while logged in as admin")
    db.delete(target)
    db.commit()
