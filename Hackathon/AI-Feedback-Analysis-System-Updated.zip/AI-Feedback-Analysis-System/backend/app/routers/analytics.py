from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from .. import stats
from ..database import get_db
from ..deps import get_current_user, require_admin
from ..models import User

router = APIRouter(prefix="/api/analytics", tags=["Analytics"])


@router.get("/me")
def my_stats(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return stats.overview(db, user.id)


@router.get("/overview")
def overview(db: Session = Depends(get_db), _: User = Depends(require_admin)):
    return stats.overview(db)


@router.get("/sentiment")
def sentiment(db: Session = Depends(get_db), _: User = Depends(require_admin)):
    return stats.sentiment_stats(db)


@router.get("/ratings")
def ratings(db: Session = Depends(get_db), _: User = Depends(require_admin)):
    return stats.rating_stats(db)


@router.get("/categories")
def categories(db: Session = Depends(get_db), _: User = Depends(require_admin)):
    return stats.category_stats(db)


@router.get("/trends")
def trends(days: int = Query(30, ge=1, le=365), db: Session = Depends(get_db), _: User = Depends(require_admin)):
    return stats.trends(db, days)


@router.get("/complaints")
def complaints(limit: int = Query(6, ge=1, le=50), db: Session = Depends(get_db), _: User = Depends(require_admin)):
    return stats.common_complaints(db, limit)


@router.get("/suggestions")
def suggestions(limit: int = Query(10, ge=1, le=50), db: Session = Depends(get_db), _: User = Depends(require_admin)):
    return stats.suggestion_analysis(db, limit)

