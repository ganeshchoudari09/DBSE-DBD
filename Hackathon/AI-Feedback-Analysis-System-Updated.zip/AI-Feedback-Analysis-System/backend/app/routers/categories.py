from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func
from sqlalchemy.orm import Session

from ..database import get_db
from ..deps import get_current_user, require_admin
from ..models import Category, Feedback, User
from ..schemas import CategoryIn, CategoryOut

router = APIRouter(prefix="/api/categories", tags=["Categories"])


def _out(db: Session, c: Category) -> dict:
    n = db.query(func.count(Feedback.id)).filter(Feedback.category_id == c.id).scalar() or 0
    return {"id": c.id, "name": c.name, "description": c.description, "feedback_count": n}


def _name_taken(db: Session, name: str, exclude_id: int | None = None) -> bool:
    q = db.query(Category).filter(func.lower(Category.name) == name.strip().lower())
    if exclude_id:
        q = q.filter(Category.id != exclude_id)
    return q.first() is not None


@router.get("", response_model=list[CategoryOut])
def list_categories(db: Session = Depends(get_db), _: User = Depends(get_current_user)):
    rows = (db.query(Category, func.count(Feedback.id)).outerjoin(Feedback, Feedback.category_id == Category.id)
            .group_by(Category.id).order_by(Category.name).all())
    return [{"id": c.id, "name": c.name, "description": c.description, "feedback_count": n} for c, n in rows]


@router.post("", response_model=CategoryOut, status_code=201)
def create_category(data: CategoryIn, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    if _name_taken(db, data.name):
        raise HTTPException(409, "A category with this name already exists")
    c = Category(name=data.name.strip(), description=data.description)
    db.add(c)
    db.commit()
    db.refresh(c)
    return _out(db, c)


@router.put("/{category_id}", response_model=CategoryOut)
def update_category(category_id: int, data: CategoryIn, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    c = db.get(Category, category_id)
    if not c:
        raise HTTPException(404, "Category not found")
    if _name_taken(db, data.name, category_id):
        raise HTTPException(409, "A category with this name already exists")
    c.name, c.description = data.name.strip(), data.description
    db.commit()
    return _out(db, c)


@router.delete("/{category_id}", status_code=204)
def delete_category(category_id: int, db: Session = Depends(get_db), _: User = Depends(require_admin)):
    c = db.get(Category, category_id)
    if not c:
        raise HTTPException(404, "Category not found")
    if _out(db, c)["feedback_count"] > 0:
        raise HTTPException(409, "Category has feedback and cannot be deleted")
    db.delete(c)
    db.commit()
