# Architecture (CO4)

```mermaid
flowchart LR
    B[Browser<br/>React + Vite + Tailwind] -- "REST/JSON + JWT<br/>/api/*" --> API[Main Backend<br/>FastAPI :8000]
    API -- "SQLAlchemy" --> DB[(SQLite<br/>database/feedback.db)]
    API -- "HTTP POST /analyze<br/>GET /health" --> AI[AI Sentiment Service<br/>FastAPI :8001<br/>VADER / built-in lexicon]
```

```mermaid
sequenceDiagram
    participant U as User
    participant F as React frontend
    participant A as Backend :8000
    participant S as AI service :8001
    participant D as SQLite
    U->>F: Submit feedback
    F->>A: POST /api/feedback (JWT)
    A->>D: INSERT feedback
    A->>S: POST /analyze {text}
    alt AI available
        S-->>A: sentiment + scores
        A->>D: INSERT sentiment_results
    else AI down / timeout
        A-->>A: log warning, status = pending
    end
    A-->>F: feedback + sentiment (or pending)
    F-->>U: Result card (retry button if pending)
```

- **Resilience:** the backend never fails a submission because the AI service is down; feedback is stored as `pending` and can be re-analyzed (`POST /api/feedback/{id}/analyze`).
- **Health checks:** `GET :8001/health`, `GET :8000/api/health` (reports DB + AI service status).
- **Security:** bcrypt password hashing, JWT bearer tokens, role-based access (`user` / `admin`); users only reach their own feedback (404 otherwise).
