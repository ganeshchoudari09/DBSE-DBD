# ER Diagram (CO1)

```mermaid
erDiagram
    USERS ||--o{ FEEDBACK : submits
    CATEGORIES ||--o{ FEEDBACK : classifies
    FEEDBACK ||--o| SENTIMENT_RESULTS : "analyzed as"
    USERS ||--o{ REPORTS : generates

    USERS {
        int id PK
        string name
        string email UK
        string hashed_password
        string role "user | admin"
        datetime created_at
    }
    CATEGORIES {
        int id PK
        string name UK
        string description
    }
    FEEDBACK {
        int id PK
        int user_id FK
        int category_id FK
        string title
        text message
        int rating "CHECK 1..5"
        datetime created_at
    }
    SENTIMENT_RESULTS {
        int id PK
        int feedback_id FK,UK
        string sentiment "positive | negative | neutral"
        float confidence
        float positive_score
        float negative_score
        float neutral_score
        datetime analyzed_at
    }
    REPORTS {
        int id PK
        int generated_by FK
        string report_type
        datetime created_at
    }
```

Rules: deleting a user cascades to their feedback and reports; deleting feedback cascades to its sentiment result;
a category that still has feedback cannot be deleted (`ON DELETE RESTRICT`). `sentiment_results.feedback_id` is unique (one result per feedback).
Full DDL: `database/schema.sql`.
