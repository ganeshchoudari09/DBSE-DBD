# AI-Based Feedback Analysis System (FeedbackIQ)

Students, employees and customers submit feedback with a star rating; a separate AI service classifies each
message as **Positive / Negative / Neutral** with scores. Admins manage feedback and categories and view live analytics.

**Stack:** React + Vite + Tailwind + Recharts · FastAPI + SQLAlchemy + JWT/bcrypt · SQLite · separate FastAPI sentiment service (VADER, with a built-in lexicon fallback).

```
AI-Feedback-Analysis-System/
├── frontend/      React app (10 pages)
├── backend/       Main FastAPI API  (app/routers, models, schemas, stats, ai_client, seed)
├── ai_service/    Sentiment microservice (analyzer.py, main.py)
├── database/      schema.sql, queries.sql (feedback.db is created on first run)
├── testing/       pytest suites
├── docs/          ER_DIAGRAM.md, ARCHITECTURE.md
└── docker-compose.yml
```

## Run locally (3 terminals)

Requires Python 3.10+ and Node 18+.

```bash
# 1) AI service  → http://localhost:8001/docs
cd ai_service
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --port 8001 --reload

# 2) Backend     → http://localhost:8000/docs
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env                                   # Windows: copy .env.example .env
python -m app.seed --demo                              # optional demo data (start AI service first)
uvicorn app.main:app --port 8000 --reload

# 3) Frontend    → http://localhost:5173
cd frontend
npm install
npm run dev
```

## Run with Docker
```bash
docker compose up --build        # app at http://localhost:3000
```

## Demo credentials
| Role  | Email                | Password     |
|-------|----------------------|--------------|
| Admin | admin@feedback.com   | Admin@123    |
| User  | student@feedback.com | Student@123  (created by `python -m app.seed --demo`) |

Anyone can also register a new user account from the UI.

## API summary (full docs at `/docs`)
- Auth: `POST /api/auth/register`, `POST /api/auth/login`, `GET /api/auth/me`
- Feedback: `POST/GET /api/feedback`, `GET/PUT/DELETE /api/feedback/{id}`, `POST /api/feedback/{id}/analyze`
- Categories: `GET/POST /api/categories`, `PUT/DELETE /api/categories/{id}` (write = admin)
- Analytics (admin): `/api/analytics/overview|sentiment|ratings|categories|trends`, user: `/api/analytics/me`
- Reports (admin): `POST /api/reports/generate`, `GET /api/reports`, `GET /api/reports/export` (CSV)
- Health: `GET :8000/api/health`, `GET :8001/health`

## Tests
```bash
pip install -r backend/requirements.txt -r ai_service/requirements.txt -r testing/requirements-test.txt
pytest testing -v
```

## Course outcome mapping
CO1 `database/schema.sql`, `docs/ER_DIAGRAM.md` · CO2 `database/queries.sql`, `backend/app/stats.py` (joins, filters, aggregates) ·
CO3 `backend/app/routers`, `schemas.py`, `security.py` · CO4 `ai_service/` + `backend/app/ai_client.py` + `docker-compose.yml` ·
CO5 `ai_service/analyzer.py`, analytics dashboards · CO6 `testing/`, this README, `docs/`.
