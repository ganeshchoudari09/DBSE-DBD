-- CO2: SQL demonstrations (run: sqlite3 database/feedback.db < database/queries.sql)

-- 1. JOIN: feedback with author, category and sentiment
SELECT f.id, u.name AS author, c.name AS category, f.title, f.rating, s.sentiment, s.confidence
FROM feedback f
JOIN users u      ON u.id = f.user_id
JOIN categories c ON c.id = f.category_id
LEFT JOIN sentiment_results s ON s.feedback_id = f.id
ORDER BY f.created_at DESC;

-- 2. FILTER: negative feedback with a low rating
SELECT f.id, f.title, f.rating, s.negative_score
FROM feedback f JOIN sentiment_results s ON s.feedback_id = f.id
WHERE s.sentiment = 'negative' AND f.rating <= 2;

-- 3. AGGREGATION: sentiment distribution
SELECT sentiment, COUNT(*) AS total, ROUND(AVG(confidence), 3) AS avg_confidence
FROM sentiment_results GROUP BY sentiment;

-- 4. AGGREGATION + JOIN: category-wise stats
SELECT c.name, COUNT(f.id) AS feedback_count, ROUND(AVG(f.rating), 2) AS avg_rating,
       SUM(CASE WHEN s.sentiment = 'positive' THEN 1 ELSE 0 END) AS positive,
       SUM(CASE WHEN s.sentiment = 'negative' THEN 1 ELSE 0 END) AS negative,
       SUM(CASE WHEN s.sentiment = 'neutral'  THEN 1 ELSE 0 END) AS neutral
FROM categories c
LEFT JOIN feedback f ON f.category_id = c.id
LEFT JOIN sentiment_results s ON s.feedback_id = f.id
GROUP BY c.id ORDER BY feedback_count DESC;

-- 5. Daily trend
SELECT date(created_at) AS day, COUNT(*) AS feedback_count FROM feedback GROUP BY day ORDER BY day;

-- 6. HAVING: users with more than one feedback
SELECT u.name, COUNT(f.id) AS submitted FROM users u JOIN feedback f ON f.user_id = u.id
GROUP BY u.id HAVING COUNT(f.id) > 1;

-- 7. Subquery: feedback rated above the overall average
SELECT id, title, rating FROM feedback WHERE rating > (SELECT AVG(rating) FROM feedback);

-- 8. CRUD examples
-- INSERT INTO categories (name, description) VALUES ('Library', 'Library services');
-- UPDATE feedback SET rating = 4 WHERE id = 1;
-- DELETE FROM feedback WHERE id = 1;   -- cascades to sentiment_results
