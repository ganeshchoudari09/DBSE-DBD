"""Sentiment engine.

Uses VADER (vaderSentiment) when installed. If it is not available, falls back to a built-in
VADER-style lexicon analyzer (valence lexicon + negation + intensifiers) so the service always works offline.
Both produce: compound score, and pos/neg/neu proportions.
"""
import math
import re

try:
    from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
    _vader = SentimentIntensityAnalyzer()
except Exception:  # pragma: no cover
    _vader = None

LEXICON = {
    # positive
    "excellent": 3.2, "great": 3.1, "good": 1.9, "amazing": 2.8, "awesome": 3.1, "fantastic": 2.6,
    "helpful": 1.8, "friendly": 2.2, "love": 3.2, "loved": 2.9, "nice": 1.8, "best": 3.2, "perfect": 2.7,
    "wonderful": 2.7, "happy": 2.7, "satisfied": 1.9, "recommend": 1.5, "quick": 1.0, "fast": 1.0,
    "clean": 1.7, "smooth": 1.5, "easy": 1.8, "supportive": 1.9, "informative": 1.8, "professional": 1.9,
    "outstanding": 3.0, "superb": 3.0, "brilliant": 2.8, "impressive": 2.3, "enjoyed": 2.2, "pleasant": 2.3,
    "polite": 1.8, "knowledgeable": 1.9, "engaging": 1.9, "useful": 1.9, "valuable": 2.0, "efficient": 1.9,
    "responsive": 1.6, "comfortable": 1.8, "thanks": 1.9, "thank": 1.5, "better": 1.9, "improved": 1.8,
    "delighted": 2.8, "satisfying": 2.0, "reliable": 1.8, "inspiring": 2.4, "clear": 1.3, "creative": 1.8,
    # negative
    "poor": -2.1, "bad": -2.5, "terrible": -2.1, "awful": -2.0, "horrible": -2.5, "worst": -3.1,
    "hate": -2.7, "hated": -3.0, "disappointing": -2.2, "disappointed": -2.1, "slow": -1.0, "rude": -2.0,
    "dirty": -1.8, "unhelpful": -2.0, "useless": -2.3, "waste": -1.8, "broken": -1.5, "late": -1.0,
    "delay": -1.2, "delayed": -1.2, "boring": -1.9, "confusing": -1.4, "crowded": -1.0, "noisy": -1.2,
    "expensive": -1.0, "unprofessional": -2.1, "ignored": -1.8, "frustrating": -2.4, "annoying": -2.0,
    "problem": -1.5, "problems": -1.5, "issue": -1.0, "issues": -1.0, "lack": -1.3, "lacking": -1.4,
    "mediocre": -1.5, "complaint": -1.5, "unacceptable": -2.3, "unhappy": -2.0, "dissatisfied": -2.0,
    "worse": -2.1, "disgusting": -2.8, "pathetic": -2.5, "careless": -1.6, "inefficient": -1.8,
}
BOOSTERS = {"very": 0.293, "extremely": 0.293, "really": 0.293, "so": 0.293, "incredibly": 0.293,
            "highly": 0.293, "absolutely": 0.293, "quite": 0.15, "slightly": -0.293, "somewhat": -0.293,
            "barely": -0.293}
NEGATORS = {"not", "no", "never", "without", "hardly", "cannot", "cant", "neither", "nor"}


def _builtin_scores(text: str) -> dict:
    tokens = re.findall(r"[a-z']+", text.lower())
    vals = []
    for i, tok in enumerate(tokens):
        v = LEXICON.get(tok, 0.0)
        if v:
            for back, scale in ((1, 1.0), (2, 0.95), (3, 0.9)):
                if i - back < 0:
                    break
                prev = tokens[i - back]
                b = BOOSTERS.get(prev, 0.0)
                if b:
                    v += (b if v > 0 else -b) * scale
            if any(t in NEGATORS or t.endswith("n't") for t in tokens[max(0, i - 3):i]):
                v *= -0.74
        vals.append(v)
    s = sum(vals)
    compound = s / math.sqrt(s * s + 15) if s else 0.0
    pos_sum = sum(v + 1 for v in vals if v > 0)
    neg_sum = sum(v - 1 for v in vals if v < 0)
    neu_count = sum(1 for v in vals if v == 0)
    total = pos_sum + abs(neg_sum) + neu_count
    if total == 0:
        return {"compound": 0.0, "pos": 0.0, "neg": 0.0, "neu": 1.0}
    return {"compound": compound, "pos": pos_sum / total, "neg": abs(neg_sum) / total, "neu": neu_count / total}


ENGINE = "vader" if _vader else "builtin-lexicon"


def analyze_text(text: str) -> dict:
    text = (text or "").strip()
    if not text:
        raise ValueError("Text must not be empty")
    sc = _vader.polarity_scores(text) if _vader else _builtin_scores(text)
    c = sc["compound"]
    if c >= 0.05:
        label = "positive"
    elif c <= -0.05:
        label = "negative"
    else:
        label = "neutral"
    conf = min(1.0, 0.5 + abs(c) / 2) if label != "neutral" else max(0.5, 1 - abs(c) * 10)
    return {
        "sentiment": label,
        "confidence": round(conf, 4),
        "positive_score": round(sc["pos"], 4),
        "negative_score": round(sc["neg"], 4),
        "neutral_score": round(sc["neu"], 4),
        "compound": round(c, 4),
        "engine": ENGINE,
    }
