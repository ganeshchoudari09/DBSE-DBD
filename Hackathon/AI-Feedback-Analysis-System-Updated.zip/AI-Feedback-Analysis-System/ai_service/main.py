"""Lightweight AI sentiment microservice (port 8001)."""
from typing import List

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

import analyzer

app = FastAPI(title="Feedback AI Sentiment Service", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


class AnalyzeIn(BaseModel):
    text: str = Field(min_length=1, max_length=10000)


class BatchIn(BaseModel):
    texts: List[str] = Field(min_length=1, max_length=100)


class AnalyzeOut(BaseModel):
    sentiment: str
    confidence: float
    positive_score: float
    negative_score: float
    neutral_score: float
    compound: float
    engine: str


@app.get("/health")
def health():
    return {"status": "ok", "service": "ai-sentiment", "engine": analyzer.ENGINE}


@app.post("/analyze", response_model=AnalyzeOut)
def analyze(body: AnalyzeIn):
    try:
        return analyzer.analyze_text(body.text)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))


@app.post("/analyze/batch", response_model=List[AnalyzeOut])
def analyze_batch(body: BatchIn):
    try:
        return [analyzer.analyze_text(t) for t in body.texts]
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
